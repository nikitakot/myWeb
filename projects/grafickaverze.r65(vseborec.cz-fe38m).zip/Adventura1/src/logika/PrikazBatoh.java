package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */


/*******************************************************************************
 * Třída PrikazBatoh implementuje IPrikaz pro hru příkaz batoh
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class PrikazBatoh implements IPrikaz
{
    private static final String NAZEV = "batoh";
    private HerniPlan plan;

    /**
     *  Konstruktor třídy
     *  
     *  @param plan herní plán
     */    
    public PrikazBatoh(HerniPlan plan) {
        this.plan = plan;
    }

    /**
     *  Provádí příkaz "batoh". Vypíše všechny věci, které jsou v batohu.
     *
     *@param parametry - jako  parametr může být cokoliv
     *@return zpráva, kterou vypíše hra hráči
     */ 
    @Override
    public String proved(String... parametry) {
        if (plan.getBatoh().getVeci().equals("")) {
            return "V batohu nic nemáš, zatím je prázdný";
        }
        else {
            return "V batohu jsou tyto věci: " + plan.getBatoh().getVeci(); 
        }
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *  
     *  @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }
}
