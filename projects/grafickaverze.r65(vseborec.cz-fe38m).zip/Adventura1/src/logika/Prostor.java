package logika;

import java.util.*;

/**
 *  Trida Prostor - popisuje jednotlivé prostory (místnosti) hry
 *
 *  Tato třída je součástí jednoduché textové hry.
 *
 *  "Prostor" reprezentuje jedno místo (místnost, prostor, ..) ve scénáři
 *  hry. Prostor může mít sousední prostory připojené přes východy. Pro
 *  každý východ si prostor ukládá odkaz na sousedící prostor.
 *
 *@author     Michael Kolling, Lubos Pavlicek, Jarmila Pavlickova, Štěpán Mazanec
 *@version    pro zimní semestr 2011/2012
 */

public class Prostor {
    private String nazev;
    private String popis;
    private Set<Prostor> vychody;   // obsahuje sousední místnosti
    private Map<String, Vec> seznamVeci;
    private Map<String, Postava> seznamPostav;
    private boolean zamcena = false;
    private Vec klic;

    /**
     * Vytvoření  prostoru se zadaným popisem, např.
     * "kuchyň", "hala", "trávník před domem"
     *
     *@param  nazev     nazev prostoru, jednoznačný identifikátor, jedno slovo nebo víceslovný název bez mezer.
     *@param  popis     Popis prostoru.
     */
    public Prostor(String nazev, String popis) {
        this.nazev = nazev;
        this.popis = popis;
        vychody = new HashSet<Prostor>();
        seznamVeci = new HashMap<>();
        seznamPostav = new HashMap<>();
    }

    /**
     * Definuje východ z prostoru (sousední/vedlejsi prostor). Vzhledem k tomu, že je použit
     * Set pro uložení východů, může být sousední prostor uveden pouze jednou
     * (tj. nelze mít dvoje dveře do stejné sousední místnosti). Druhé zadání
     * stejného prostoru tiše přepíše předchozí zadání (neobjeví se žádné chybové hlášení).
     * Lze zadat též cestu ze do sebe sama.
     * 
     * @param vedlejsi prostor, který sousedi s aktualnim prostorem.
     *
     */
    public void setVychod(Prostor vedlejsi) {
        vychody.add(vedlejsi);
    }

    /**
     * Metoda equals pro porovnání dvou prostorů. Překrývá se metoda equals ze třídy Object.
     * Dva prostory jsou shodné, pokud mají stejný název.
     * Tato metoda je důležitá z hlediska správného fungování seznamu východů (Set).
     * 
     * Bližší popis metody equals je u třídy Object.
     *
     *@param   o  object, který se má porovnávat s aktuálním
     *@return     hodnotu true, pokud má zadaný prostor stejný název, jinak false
     */

    @Override
    public boolean equals (Object objt) {
        if (objt instanceof Prostor) {
            Prostor druhy = (Prostor)objt;
            return nazev.equals(druhy.nazev);
        }
        else {
            return false;
        }
    }

    /**
     * metoda hashCode vraci ciselny identifikator instance, ktery se pouziva pro optimalizaci ukladani
     * v dynamickych datovych strukturach. Pri prekryti metody equals je potreba prekryt i metodu hashCode.
     * Podrobny popis pravidel pro vytvareni metody hashCode je u metody hashCode ve tride Object
     */

    @Override
    public int hashCode() {
        return nazev.hashCode();
    }

    /**
     * Vrací název prostoru (byl zadán při vytváření prostoru jako
     * parametr konstruktoru)
     *
     *@return    název prostoru
     */
    public String getNazev() {
        return nazev;
    }

    /**
     * Vrací "dlouhý" popis prostoru, který může vypadat následovně:
     *      Jsi v mistnosti/prostoru vstupni hala budovy VSE na Jiznim meste.
     *      vychody: chodba bufet ucebna
     *
     *@return    Dlouhý popis prostoru
     */
    public String dlouhyPopis() {
        return "Jsi v mistnosti/prostoru " + nazev + ". " + popis + ".\n"
        + popisVychodu() + ".\n"
        + popisVeci() + ".\n"
        + popisPostav();
    }

    /**
     * Vrací textový řetězec, který popisuje sousední východy, například:
     * "vychody: hala ".
     *
     *@return    Popis východů - názvů sousedních prostorů
     */
    private String popisVychodu() {
        String vracenyText = "vychody:";
        for (Prostor sousedni : vychody) {
            vracenyText += " " + sousedni.getNazev();
        }
        return vracenyText;
    }

    /**
     * Vrací testový řetězec, který vypíše všechny věci v místnosti, pokud jsou viditelné
     * a pokud nejsou v jiných věcech
     *
     * @return seznam věcí
     */
    private String popisVeci() {
        String vracenyText = "věci:";
        for (String nazev : seznamVeci.keySet()) {
            if(seznamVeci.get(nazev).isViditelnost()) {
                vracenyText += " " + nazev;
            }
        }

        return vracenyText;
    }

    /**
     * Vrací textový řetězec postav, které se nachází v místnosti
     *
     * @return seznam postav
     */
    private String popisPostav() {
        String vracenyText = "postavy:";
        for (String jmeno : seznamPostav.keySet()) {
            vracenyText += " " + jmeno ;
        }
        return vracenyText;
    }

    /**
     * Vrací prostor, který sousedí s aktuálním prostorem a jehož název je zadán
     * jako parametr. Pokud prostor s udaným jménem nesousedí s aktuálním prostorem,
     * vrací se hodnota null.
     *
     *@param  nazevSouseda  Jméno sousedního prostoru (východu)
     *@return            Prostor, který se nachází za příslušným východem, nebo
     *                   hodnota null, pokud prostor zadaného jména není sousedem.
     */
    public Prostor vratSousedniProstor(String nazevSouseda) {
        if (nazevSouseda == null) {
            return null;
        }
        for ( Prostor sousedni : vychody ){
            if (sousedni.getNazev().equals(nazevSouseda)) {
                return sousedni;
            }
        }
        return null;  // prostor nenalezen
    }

    /**
     * Vrací kolekci obsahující prostory, se kterými tento prostor sousedí.
     * Takto získaný seznam sousedních prostor nelze upravovat (přidávat, odebírat východy)
     * protože z hlediska správného návrhu je to plně záležitostí třídy Prostor.
     *
     *@return    Nemodifikovatelná kolekce prostorů (východů), se kterými tento prostor sousedí.
     */
    public Collection<Prostor> getVychody() {
        return Collections.unmodifiableCollection(vychody);
    }

    /**
     * Metoda vloží věc do prostoru
     *
     * @param neco - vkládaná věc
     * @return true pokud se ji podaří vložit
     */
    public boolean vlozVec(Vec neco){
        seznamVeci.put(neco.getNazev(), neco);
        return true;
    }

    /**
     * Metoda vybere věc z místnosti
     *
     * @return vrátí vybranou věc
     */
    public Vec seberVec(String jmeno) {
        Vec sbirana = null;
        for (String nazev : seznamVeci.keySet()) {
            if (nazev.equals(jmeno)& seznamVeci.get(nazev).isPrenositelnost()){
                sbirana = seznamVeci.get(nazev);
                seznamVeci.remove(nazev);
                break;
            }    
            if ((seznamVeci.get(nazev)).obsahujeVec(jmeno)) {
                sbirana = (seznamVeci.get(nazev)).vyberVec(jmeno);
                seznamVeci.remove(sbirana);
                break;
            }
        }
        
        return sbirana;
    }

    /**
     * Vrací zda se věc nachází v prostoru (i ve věcech)
     *
     * @return true pokud se prostoru nachází
     */
    public boolean obsahujeVec(String jmeno) {         
        for (String nazev : seznamVeci.keySet()) {
            if (nazev.equals(jmeno)) {
                return true;
            }
            if ((seznamVeci.get(nazev)).obsahujeVec(jmeno)) {
                return true;
            }
        }     
        return false;  // věc není ani v prozkoumaných věcech
    }

    /**
     * Vrací zda se věc nachází v místnosti (ne ve věcech)
     *
     * @return vrátí nalezenou věc
     */
    public Vec obsahujeVecMistnost(String nazev) {
        return seznamVeci.get(nazev);
    }

    /**
     * Vloží postavu do prostoru
     *
     * @param postava - jméno postavu kterou chceme vložit
     * @return true pokus se podaží vložit
     */
    public boolean vlozPostavu(Postava postava) {
        seznamPostav.put(postava.getJmeno(), postava);
        return true;
    }

    /**
     * Vrací jméno postavy pokud se nachází v místnosti
     *
     * @return nalezené postavy
     */
    public Postava existujePostava(String jmeno) {
        return seznamPostav.get(jmeno);
    }

    /**
     * Odstraní postavu z místnosti
     *
     * @param jmeno - jméno odstraňované postavy
     * @return true pokud se podaří odstranit
     */
    public boolean odstranPostavu(String jmeno) {
        seznamPostav.remove(jmeno);
        return true;
    }

    /**
     * Vrací zda je prostor zamčení
     *
     * @return true - je zamčen
     */
    public boolean isZamcena() {
        return zamcena;
    }

    /**
     * Nastavuje prostor na zamčený či ne
     *
     * @param zamcena - true pokud má být zamčen
     */
    public void setZamcena(boolean zamcena) {
        this.zamcena = zamcena;        
    }

    /**
     * Metoda vrací klíč přiřazený určitému prostoru
     *
     * @return klíč
     */
    public Vec getKlic() {
        return klic;
    }

    /**
     * Metoda nastaví klíč zamčenému prostoru
     */
    public void setKlic(Vec klic) {
        this.klic = klic;
    }

}
