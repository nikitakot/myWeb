package logika;

import java.util.*;
import grafika.PredplatitelZmenyBatohu;
import grafika.VydavatelZmenyBatohu;
/**
 * Třída batoh reprezentuje práci s věcmi v batohu (inventáři).
 * Tato třída obsahuje metody, které umožnují práci s věcmi v batohu a zpřístupňuje funkce jako
 * vkládání věci, odebírání věcí, apod.
 * Tato třída je součástí jednoduché textové hry.
 * 
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class Batoh implements VydavatelZmenyBatohu
{
    private Map<String, Vec> seznamVeci;
    private static final int MAX_VECI = 3;
    private List<PredplatitelZmenyBatohu>seznamPredplatiteluB = new ArrayList<>();
    
    
    /**
     * Konstruktor třídy
     */
    public Batoh()
    {
        seznamVeci = new HashMap<>();
    }
    
    /**
     * Tato metoda přidá věc do batohu (pokud je tam místo)
     *
     * @param neco - věc, kterou přidáváme do batohu
     * @return true pokud se podaří věc přidat, false pak pro opak
     */
    public boolean vlozVec(Vec neco){
        if (isMisto()){
            seznamVeci.put(neco.getNazev(),neco);
            upozorniPredplatiteleBatohu();
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Tato metoda odstraní věc z batohu (pokud je v batohu)
     *
     * @param neco - věc, kterou odstraňujeme z batohu
     * @return true pokud se odstraní, false pak pro opak
     */
    public boolean odlozVec(String neco) {
        boolean vyhozena = false;
        if (seznamVeci.containsKey(neco)) {
            vyhozena = true;
            seznamVeci.remove(neco);
            upozorniPredplatiteleBatohu();

        }
        return vyhozena;
    }

    /**
     * Tato metoda zištujě zda věc je v batohu, nebo ne
     *
     * @param nazev - nazev věci kterou hledáme
     * @return true pokud je v batohu, false pak pro opak
     */
    public boolean obsahujeVec (String nazev) {
        return (seznamVeci.containsKey(nazev));
    }

    /**
     * Tato metoda hledá věc, kterou chceme hledat
     * @return hledaná věc
     */
    public Vec getVec(String nazev) {
        return seznamVeci.get(nazev);
    }

    /**
     * Metoda zjišťujě kolik věcí je v batohu
     *
     * @return true pokud se může přidat ještě další věc
     */
    public boolean isMisto() {
        return (seznamVeci.size() < MAX_VECI);
    }

    /**
     * Metoda pro zjištění obsahu batohu
     *
     * @return seznam věcí v batohu
     */
    public String getVeci() {
        String text = "";
        for (String nazev : seznamVeci.keySet()) {
            text +=  nazev + " ";
        }
        return text;
    }
    /**
     * Metoda vracející seznam predmětů
     * @return  seznam předmětů
     */
    public HashMap<String, Vec> seznamPredmetu(){
        return (HashMap<String, Vec>)seznamVeci;
    }

    @Override
    public void zaregistrujPredplatitele(PredplatitelZmenyBatohu predplatitel) {
        seznamPredplatiteluB.add(predplatitel);
    }

    @Override
    public void odregistrujPredplatitele(PredplatitelZmenyBatohu predplatitel) {
        seznamPredplatiteluB.remove(predplatitel);
    }

    @Override
    public void upozorniPredplatiteleBatohu() {
        for (PredplatitelZmenyBatohu predplatitel : seznamPredplatiteluB) {
            predplatitel.aktualizuj(this);
        }
    }

}

