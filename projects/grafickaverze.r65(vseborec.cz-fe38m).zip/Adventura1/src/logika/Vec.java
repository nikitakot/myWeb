package logika;

import java.util.*;

/*******************************************************************************
 * Třída pro věci a jejich vlastnosti
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class Vec
{
    private String nazev;
    private boolean prenositelnost;
    private boolean viditelnost;
    private boolean isProzkoumana = false;
    private Map<String, Vec> seznamVeci;

    /**
     * Konstruktor třídy
     */
    public Vec(String nazev, boolean prenositelnost, boolean viditelnost)
    {
        this.nazev = nazev;
        this.prenositelnost = prenositelnost;
        this.viditelnost = viditelnost;
        this.seznamVeci = new HashMap<>();
    }

    /**
     * Metoda vrací jméno věci
     *
     * @return jméno věci
     */
    public String getNazev() {
        return nazev;
    }

    /**
     * Metoda vrací jestli je věc přenositelná
     *
     * @return true - je-li přenositelná
     */
    public boolean isPrenositelnost(){
        return prenositelnost;
    }

    /**
     * Metoda vrací viditelnost
     *
     * @return true - je-li viditelná
     */
    public boolean isViditelnost() {
        return viditelnost;
    }

    /**
     * Metoda vrací zda je věc ve věci prozkoumaná
     *
     * @return true - je-li prozkoumaná
     */
    public boolean isProzkoumana() {
        return isProzkoumana;
    }

    /**
     * Metoda vloží věc do věci
     *
     * @param vec - kterou chceme vložit
     */
    public void vlozVec (Vec vec) {
        seznamVeci.put(vec.getNazev(), vec);
    }

    /**
     * Metoda nastavuje věc zda je prozkoumaná či ne
     *
     * @param isProzkoumana - true pokud je prozkoumaná
     */
    public void setProzkoumana (boolean isProzkoumana) {
        this.isProzkoumana = isProzkoumana;
    }

    /**
     * Metoda při prozkoumání věci vypíše věci, které obsahuje
     *
     * @return zpráva, kterou hra vypíše hráči
     */
    public String popisProzkoumej() {
        String popis;
        if (seznamVeci.isEmpty()) {
            popis = "Nic jsi nenašel";
        }
        else {
            popis = "V " + nazev + " jsi našel: ";
            for (String nazev : seznamVeci.keySet()) {
                popis += nazev + ", "; 
            }
        }
        return popis;
    }

    /**
     * Metoda zjistí jetsli se věc nachází v jiné.
     *
     * @return true- pokud je věc v jiné
     */
    public boolean obsahujeVec(String nazev) {
        return isProzkoumana && seznamVeci.containsKey(nazev);
    }

    /**
     * Metoda vrací seznam věcí v jiné věci
     *
     * @return seznam věcí
     */
    public String getSeznamVeci() {
        String veci = "";
        for (String nazev : seznamVeci.keySet()) {
            veci += nazev + " ";
        }
        return veci;       
    }

    /**
     * Metoda vybere věc z jíné prozkoumané věci
     *
     * @return vrátí vybranou věc
     */
    public Vec vyberVec(String jmeno) {
        Vec vec = null;
        if (isProzkoumana && seznamVeci.containsKey(jmeno)) {
            vec = seznamVeci.get(jmeno);
            if (vec.isPrenositelnost()) {
                seznamVeci.remove(jmeno);
            }
        }
        return vec;
    }
}

