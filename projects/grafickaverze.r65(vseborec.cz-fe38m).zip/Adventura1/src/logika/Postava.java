package logika;

/*******************************************************************************
 * Třída pracuje s postavami
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class Postava
{
    private String jmeno;
    private String rec;

    /**
     * Konstruktor třídy
     */
    public Postava(String jmeno, String rec)
    {
        this.jmeno = jmeno;
        this.rec = rec;        
    }

    /**
     * Metoda vrací jméno postavy
     *
     * @return jméno postavy
     */
    public String getJmeno() {
        return jmeno;
    }

    /**
     * Metoda vrací řeč postavy, když se s ní mluví
     *
     * @return řeč
     */
    public String getRec() {
        return rec;
    }

    /**
     * Metoda nastaví řeč postavě 
     *
     * @param novaRec - co má postava odpovědět
     * @return nová řeč
     */
    public String setRec(String novaRec) {
        return this.rec = novaRec;
    }

    
}
