package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */

/*******************************************************************************
 * Třida PrikazOdemkni implementuje Iprikaz pro hru příkaz odemkni
 *Obsahuje metody, které používame na odemykání zamknutých místností
 *Tato třída je součástí jednoduché textové hry
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class PrikazOdemkni implements IPrikaz
{
    private static final String NAZEV = "odemkni";
    private HerniPlan plan;

    /***************************************************************************
     *
     */
    public PrikazOdemkni(HerniPlan plan)
    {
        this.plan = plan;

    }

    /**
     * Metoda pracuje s příkazem odemkni.Nastaveným klíčem odemkne zamčený prostor/místnost, kterému byla nastavena hodnota zamčeno.
     * Pokud hráč neurčí konkrétní místnost kterou chce odemknout nebo zadá neexistující sousední prostor,
     * potom adventura vypíše chybovou hlášku. Chybové hlášky jsou vypsány i v případě,že v batohu neni klíč,
     * nebo je-li místnost už odemčena.Jestliže je místnost odemčena příslušným klíčem a existuje sousedni prostor,
     * vypíše se zpráva o úspěšném odemčení prosotoru.
     * 
     * @param parametry - parametr je název místnosti bez diakritiky ,kterou chci zamknout
     * @return zpráva, kterou vypíše adventura hráči
     */
    
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            return "Kterou místnost chcete odemknout?";  
        }

        String prostor = parametry[0];
        Prostor sousedniProstor = plan.getAktualniProstor().vratSousedniProstor(prostor);

        if (sousedniProstor == null) {
            return "Takový sousedni prostor tu není.";
        }
        if (sousedniProstor.isZamcena()) {
            if (plan.getBatoh().obsahujeVec(sousedniProstor.getKlic().getNazev())) {
                sousedniProstor.setZamcena(false);
                plan.getBatoh().odlozVec(sousedniProstor.getKlic().getNazev());
                return "Je odemčeno, můžeš jít.";

            }
            else {
                return "Nemáš klíč , sežeň ho.";
            }
        }
        else {

            return "Tato místost je odemčená.";
        }
    }

    
    /**
     *  Tato metoda vrací název příkazu 
     *  
     *  @ return nazev prikazu
     */
    public String getNazev() {
        return NAZEV;
    }
}
