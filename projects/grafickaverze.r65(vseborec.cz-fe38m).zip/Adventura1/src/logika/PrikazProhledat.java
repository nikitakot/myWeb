package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */


/*******************************************************************************
 * Třída PrikazProhledat implementuje IPrikaz pro hru příkaz prohledat
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class PrikazProhledat implements IPrikaz
{
    private static final String NAZEV = "prohledat";
    private HerniPlan plan;

    /**
     *  Konstruktor třídy
     *  
     *  @param plan herní plán
     */    
    public PrikazProhledat(HerniPlan plan) {
        this.plan = plan;
    }

    /**
     *  Provádí příkaz "prohledat". Prohledá určitou věc v  prostoru.
     *  Pokud se věc v prostoru nenachází vypíše chybovou hlášku, pokud se ve věci nic nenachází,
     *  vypíše, že tam nic není. Jinak se vypíší předměty "schované" v prohledávané věci.
     *
     *@param parametry - jako  parametr obsahuje jméno prohledávané věci
     *@return zpráva, kterou vypíše hra hráči
     */ 
    @Override
    public String proved(String... parametry) {
        String text = "";
        if (parametry.length == 0) {
            // pokud chybí druhé slovo (název sbírané věci), tak ....
            return "Nevím co mám prohledat,zadej jméno věci!";
        }

        String nazevVeci = parametry[0];

        Prostor aktualniProstor = plan.getAktualniProstor();

        if (aktualniProstor.obsahujeVec(nazevVeci)) {
            Vec hledana = aktualniProstor.obsahujeVecMistnost(nazevVeci);
            if (hledana != null) {
                hledana.setProzkoumana(true);
                text = hledana.popisProzkoumej();
            }

        }
        else {
            text = "Taková věc tu neni";
        }
        return text;
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *  
     *  @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }

    
}
