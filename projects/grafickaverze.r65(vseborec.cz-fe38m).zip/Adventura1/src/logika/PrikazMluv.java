package logika;


import logika.Prostor;

/*******************************************************************************
 * třída PrikazMluv implementuje IPrikaz pro hru příkaz mluv
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class PrikazMluv implements IPrikaz
{
    private static final String NAZEV = "mluv";
    private HerniPlan plan;

    /**
     * Konstruktor třídy
     *
     * @param plan herní plán
     */
    public PrikazMluv(HerniPlan plan)
    {
        this.plan = plan;
    }

    /**
     * Vykonává příkaz "mluv". Mluví se zadanou postavou. Pokud se zadaná postava v protoru nenachází
     * vypíše chybovou hlášku.
     * 
     * @param parametr - jako  parametr obsahuje jméno postavy, s kterou má mluvit.
     * @return odpověď, kterou vypíše hra hráči
     */

    public String proved(String... parametry) { 
        if (parametry.length == 0) {
            return "Musíš napsat s kým mám mluvit";
        }
        String jmeno = parametry[0];
        Prostor aktualniProstor = plan.getAktualniProstor();
        Postava postava = aktualniProstor.existujePostava(jmeno);
        if (postava == null) {
            return "Tato postava tu není.";
        }
        else {
            return postava.getRec();
        }
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *  
     *  @ return nazev prikazu
     */

    @Override
    public String getNazev() {
        return NAZEV;
    }


}
