package logika;


/*******************************************************************************
 * Třída PrikazSeber implementuje IPrikaz pro hru příkaz seber
 *
 * @author    Štěpán Mazanec    
 * @version   1.00.000
 */
public class PrikazSeber implements IPrikaz
{
    private static final String NAZEV = "seber";
    private HerniPlan plan;
    private Batoh batoh; 
    /**
     *  Konstruktor třídy
     *  
     *  @param plan herní plán 
     */    
    public PrikazSeber(HerniPlan plan) {
        this.plan = plan;
        this.batoh = plan.getBatoh();
    }
    
    /**
     *  Provádí příkaz "seber". Zkouší sebrat zadaný předmět. Pokud v prostoru
     *  existuje a je přenositelný, sebere ho a uloží do batohu, 
     *  jinak vypíše chybové hlášení.
     *
     *@param parametry - jako  parametr obsahuje jméno věci,
     *                         kterou má sebrat
     *@return zpráva, kterou vypíše hra hráči
     */ 
    @Override
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            // pokud chybí druhé slovo (název sbírané věci), tak ....
            return "Co mám sebrat? Zadej jméno věci";
        }

        String nazevVeci = parametry[0];
        Prostor aktualniProstor = plan.getAktualniProstor();
        

        if (aktualniProstor.obsahujeVec(nazevVeci)) {
            Vec sbirana = aktualniProstor.seberVec(nazevVeci); //prostor mi jí dá podle přenositelnosti
            if (sbirana == null) {
                return "Tohle nejde zvednout";
            }
            else {
                if (batoh.vlozVec(sbirana)) {
                    return "Věc " + nazevVeci + " byla vložena do batohu." ;
                }
                else {
                    aktualniProstor.vlozVec(sbirana);
                    return "Věc se nevejde do batohu";
                }
                
            }
        }
        else {
            return "Nic takového tu není";
        }
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *  
     *  @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }
}
