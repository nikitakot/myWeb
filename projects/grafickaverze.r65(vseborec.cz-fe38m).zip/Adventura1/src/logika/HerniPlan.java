package logika;


import grafika.PredplatitelZmenyAktualnihoProstoru;
import grafika.VydavatelZmenyAktualnihoProstoru;
import java.util.ArrayList;
import logika.Prostor;


/**
 *  Class HerniPlan - třída představující mapu adventury.
 * 
 *  Tato třída inicializuje prvky ze kterých se hra skládá:
 *  vytváří všechny prostory,
 *  propojuje je vzájemně pomocí východů 
 *  a pamatuje si aktuální prostor, ve kterém se hráč právě nachází.
 *
 *@author     Michael Kolling, Lubos Pavlicek, Jarmila Pavlickova, Štěpán Mazanec
 *@version    pro školní rok 2012/2013
 */
public class HerniPlan implements VydavatelZmenyAktualnihoProstoru {
    private Prostor aktualniProstor;
    private Prostor viteznyProstor;
    private Prostor smrti;
    private Batoh batoh;
    /**
     *  Konstruktor který vytváří jednotlivé prostory a propojuje je pomocí východů.
     *  Jako výchozí aktuální prostor nastaví halu.
     */
    public HerniPlan() {
        batoh = new Batoh();
        zalozProstoryHry();
    }

    /**
     *  Vytváří jednotlivé prostory a propojuje je pomocí východů.
     *  Jako výchozí aktuální prostor nastaví příjezdovou cestu.
     */
    private void zalozProstoryHry() {
        // vytvářejí se jednotlivé prostory
        Prostor prijezdova_cesta = new Prostor("prijezdova_cesta","příjezdová cesta, začátek hry");
        Prostor nadvori = new Prostor("nadvori","nádvoří,odsud můžete jít do ostatních místností");
        Prostor tajemna_komnata = new Prostor("tajemna_komnata","Nechal ses nachytat!");
        Prostor kralovo_komnata = new Prostor("kralovo_komnata","královo komnata,zde se nachází král a klíč od truhly");
        Prostor mistnost_s_truhlou = new Prostor("mistnost_s_truhlou","místnost s truhlou ve které je měč");
        Prostor mistnost_s_pokladem = new Prostor("mistnost_s_pokladem","místnost s pokladem, vaše výherní místo");
        Prostor mistnost_s_drakem = new Prostor("mistnost_s_drakem","místnost s drakem,zabijte draka!!");    
        // přiřazují se průchody mezi prostory (sousedící prostory)
        prijezdova_cesta.setVychod(nadvori);
        nadvori.setVychod(tajemna_komnata);
        tajemna_komnata.setVychod(nadvori);
        nadvori.setVychod(kralovo_komnata);
        kralovo_komnata.setVychod(nadvori);
        nadvori.setVychod(mistnost_s_truhlou);
        mistnost_s_truhlou.setVychod(nadvori);
        nadvori.setVychod(mistnost_s_pokladem);
        mistnost_s_pokladem.setVychod(nadvori);
        nadvori.setVychod(mistnost_s_drakem);
        mistnost_s_drakem.setVychod(nadvori);
        // zamkne prostor a nastaví klíč
        mistnost_s_truhlou.setZamcena(true);
        Vec klicA = new Vec("klicA", true, true);
        mistnost_s_truhlou.setKlic(klicA);
        Vec klicB = new Vec("klicB", false, false);
        mistnost_s_drakem.vlozVec(klicB);
        mistnost_s_pokladem.setZamcena(true);
        mistnost_s_pokladem.setKlic(klicB);
       
        aktualniProstor = prijezdova_cesta;  // hra začíná na příjezdové cestě ke hradu
        viteznyProstor = mistnost_s_pokladem;     // hra končí v místnosti s pokladem a stávate se vítězem
        smrti = tajemna_komnata;
        // vloží věc
        kralovo_komnata.vlozVec(klicA);
        Vec truhla = new Vec ("truhla", false, true);  //seber a to v "zelenym"
        mistnost_s_truhlou.vlozVec(truhla);
        Vec mec = new Vec ("mec", true, true);  //prvni boolean je jeslti to de zvednout a druha jestli je to videt
        truhla.vlozVec(mec);
        Vec poklad = new Vec ("poklad",true, true);
        mistnost_s_pokladem.vlozVec(poklad);
        //vloží postavu
        Postava kral = new Postava("kral","Vítej zachránče, místnost s truhlou jsem zamkl na klíč.\n V truhle najdeš meč ,kterým zabij draka");
        kralovo_komnata.vlozPostavu(kral);
        Postava drak = new Postava("drak","");
        mistnost_s_drakem.vlozPostavu(drak);

    }

    /**
     *  Metoda vrací odkaz na aktuální prostor, ve ktetém se hráč právě nachází.
     *
     *@return     aktuální prostor
     */

    public Prostor getAktualniProstor() {
        return aktualniProstor;
    }

    /**
     * Metoda vrací odkaz na aktuální batoh
     *
     * @return batoh
     */
    public Batoh getBatoh() {
        return batoh;
    }

    /**
     *  Metoda nastaví aktuální prostor, používá se nejčastěji při přechodu mezi prostory
     *
     *@param  prostor nový aktuální prostor
     */
    public void setAktualniProstor(Prostor prostor) {
        aktualniProstor = prostor;
        upozorniPredplatitele();
    }

    /**
     * Metoda určuje zda jste vyhráli
     *
     * @return true pokud aktuální prostor je ten vítězný
     */
    public boolean vyhrano() {
        return (aktualniProstor.equals(viteznyProstor)); 
    }
    // funkce mistnosti smrti
    public boolean moznostsmrti() {
        return (aktualniProstor.equals(smrti)); 
    }
    
    private ArrayList<PredplatitelZmenyAktualnihoProstoru> seznamPredplatitelu = new ArrayList<>();

    @Override
    public void zaregistruj(PredplatitelZmenyAktualnihoProstoru predplatitel) {
        seznamPredplatitelu.add(predplatitel);
        predplatitel.update(aktualniProstor);
    }

    @Override
    public void odregistruj(PredplatitelZmenyAktualnihoProstoru predplatitel) {
        seznamPredplatitelu.remove(predplatitel);
    }

    @Override
    public void upozorniPredplatitele() {
       for(PredplatitelZmenyAktualnihoProstoru predplatitel: seznamPredplatitelu){
           predplatitel.update(aktualniProstor);
       }
    }

}
