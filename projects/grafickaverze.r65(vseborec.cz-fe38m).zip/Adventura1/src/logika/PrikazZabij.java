package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */


/*******************************************************************************
 * Třáda PrikazBojuj implementuje IPrikaz pro hru příkaz seber
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class PrikazZabij implements IPrikaz
{
    private static final String NAZEV = "zabij";
    private HerniPlan plan;

    /**
     * Konstruktor třídy
     *
     * @param plan herní plán
     */
    public PrikazZabij(HerniPlan plan)
    {
        this.plan = plan;

    }

    /**
     * Provádí příkaz "zabij".Zabije postavu v místnosti. Pokud se postava nenachází v této místosti,
     * vypíše se chybová hláška. Jinak ji zabije .
     *
     * @param parametry - jako parametr obsahuje jméno postavy, kterou má zabít
     * @return zpráva, kterou hra vypíše hráči
     */
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            return "S kým mám bojovat";  
        }

        String jmeno = parametry[0];
        Prostor aktualniProstor = plan.getAktualniProstor();
        Postava postava = aktualniProstor.existujePostava(jmeno);

        if (postava == null) {
            return "Tato postava tu není.";
        }
        else {
            if (postava.getJmeno().equals("drak")) {
                if (plan.getBatoh().obsahujeVec("mec")) {
                    
                    plan.getBatoh().vlozVec(new Vec("klicB",true,true));
                    return postava.getRec() + "Zabil jsi draka, věc 'klicB' byla přidána do batohu";
                    
                     
                }
                else {
                    
                          
                        return "Bez meče bojovat nebudu";
                    
                   
                        }
                    }
                    
                
            
            else {
                return "S touto postavou nelze bojovat";
            }
        }

    }

    /**
     * Metoda vrací název příkazu (slovo, které používá hrác pro jeho vyvolání
     *
     * @return název příkazu
     */
    public String getNazev() {
        return NAZEV;
    }

}
