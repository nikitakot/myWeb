package grafika;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.awt.Event.*;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import logika.Hra;
import logika.HerniPlan;
import start.EasyLogger;

/**
 *
 * @author Štěpán Mazanec
 */
/**
 * Metoda HlavniOkno implementuje grafické prvky: panely,framy,textfield,button,textArea
 * label...
 */
public class HlavniOkno {
    private JFrame hlOkno;
    private JTextArea vypis;
    private JTextField vstupPrikazu;
    private JButton tlacitkoKonec;
    private Hra hra;
    private Planek mujPlanek;
    private PanelVychodu panelVychodu;
    private OknoNapovedy oknoNapovedy;
    private JMenuBar vyberMenu;
    private JMenuItem novaHra;
    private JMenuItem napoveda;
    private JMenuItem konec;
    private JMenuItem zobrazeniLogu;
    private PanelBatohu panelBatohu;
    private OknoLogger oknoLogger;
    /**
     * Vytvoření základního okna pro hru do kterého se vkládají prvky
     */
    public HlavniOkno() {
        hra = new Hra();
        hlOkno = new JFrame();
        hlOkno.setTitle("King");
        hlOkno.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        hlOkno.setLayout(new BorderLayout());
        vypis = new JTextArea(20, 40);
        vypis.setEditable(false);
        // nastavuji prázdné orámování o velikost 3 px, tím bude text dál od kraje
        vypis.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        vypis.setText(hra.vratUvitani());
        vypis.setBackground(Color.GRAY);
        
        oknoLogger = new OknoLogger();
        zobrazeniLogu(hra.vratUvitani());
        
        vyberMenu = new JMenuBar();
        hlOkno.setJMenuBar(vyberMenu);
        
        JMenu menu = new JMenu("Menu");
        vyberMenu.add(menu);
        
        konec = new JMenuItem("Konec");
        konec.addActionListener(new konecaction());
        
        novaHra = new JMenuItem("Nová hra");
        novaHra.addActionListener(new startaction());
        
         napoveda = new JMenuItem("Nápověda");
        napoveda.addActionListener(new Napoveda());
        
        zobrazeniLogu = new JMenuItem("Zobrazení logu");
        zobrazeniLogu.addActionListener(new OvladacLog());
        
        menu.add(konec);
        menu.add(novaHra);
        menu.add(napoveda);
        menu.add(zobrazeniLogu);
        
        JScrollPane posuvnyPanel = new JScrollPane(vypis);
        
         posuvnyPanel.setBorder(BorderFactory.createEmptyBorder());
        // zvětšuji šířku posuvného panelu o šířku posuvníku
        posuvnyPanel.setPreferredSize(
                new Dimension(vypis.getPreferredSize().width+18,
                vypis.getPreferredSize().height));
        
        hlOkno.add(posuvnyPanel);
        hlOkno.add(dolniPanel(), BorderLayout.SOUTH);
        panelVychodu = new PanelVychodu(this);
        hlOkno.add(panelVychodu, BorderLayout.EAST);
        panelVychodu.setBackground(Color.CYAN);
        panelBatohu = new PanelBatohu(hra.getHerniPlan().getBatoh());
        panelBatohu.aktualizuj(hra.getHerniPlan().getBatoh());
        panelBatohu.setPreferredSize(new Dimension(200, 240));
        panelBatohu.setBackground(Color.WHITE);
        panelBatohu.setBorder(BorderFactory.createTitledBorder("Obsah batohu"));
        
        hra.getHerniPlan().zaregistruj(panelVychodu);
        hra.getHerniPlan().zaregistruj(mujPlanek);
        
        hra.getHerniPlan().upozorniPredplatitele();
        hlOkno.add(panelBatohu,BorderLayout.WEST);
        vypisAndLog(hra.vratUvitani());
        hlOkno.pack();
        vstupPrikazu.requestFocusInWindow();
    }
    /**
     * Metoda vypíše do logu text zadaný v parametru
     * @param String line  - jako text vypisovaný do logu
     */
    private void zobrazeniLogu(String line) {
        EasyLogger.appendText(line);
    }
    /**
     * Metoda vytvoří panel ve spodní částim patří sem příkazová řádka, tlačítko proveď
     * konec
     * @return vrací vytvořený dolní panel
     */
    private JPanel dolniPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.RED);
        
        JLabel zadejPrikaz = new JLabel("Zadej příkaz: ");
        panel.add(zadejPrikaz);
        vstupPrikazu = new JTextField(20);
        panel.add(vstupPrikazu);
        vstupPrikazu.addActionListener(new HlavniOkno.OvladacVstupniRadky());
        vytvorTlacitkoKonec();
        panel.add(Box.createHorizontalStrut(50));
        panel.add(tlacitkoKonec);
        
        tlacitkoKonec.addActionListener(new HlavniOkno.ObsluhaTlacitkaKonec());
        mujPlanek = new Planek(this);
        panel.add(mujPlanek);
        
        panel.setBackground(new Color(0xff, 0xcb, 0x73));
        vstupPrikazu.setBackground(new Color(0xfd, 0x3f, 0x49));
        
        vstupPrikazu.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xa3,0x00,0x08), 1, true),
                BorderFactory.createEmptyBorder(3, 3, 3, 3)));
        vstupPrikazu.setForeground(Color.WHITE);
        vstupPrikazu.setFont(vstupPrikazu.getFont().deriveFont(Font.BOLD, 12));
        
        return panel;
    }
    /**
     * Zobrazuje plánek hry
     * @return plánek(jpg)
     */
    
     private JComponent getPlanek() {
        Icon planekIcon = createIcon("Adventura jpg.png");
        JLabel planekLabel = new JLabel(planekIcon);
        return planekLabel;
    }
    /**
     * Vytvoří tlačítko pro ukončení hry
     * Zobrazeno v podobě barevných koleček(obrázků)
     */
     
    private void vytvorTlacitkoKonec() {
        tlacitkoKonec = new JButton();
        tlacitkoKonec.setContentAreaFilled(false);
        tlacitkoKonec.setBorder(BorderFactory.createEmptyBorder());
        tlacitkoKonec.setIcon(createIcon("Blue_button.jpg"));
        tlacitkoKonec.setSelectedIcon(createIcon("green_ball.png"));
        tlacitkoKonec.setDisabledIcon(createIcon("black_ball.png"));
        tlacitkoKonec.setRolloverIcon(createIcon("red_ball.png"));
        tlacitkoKonec.setToolTipText("konec");
    }
    
    private Icon createIcon(String jmenoSouboru) {
        URL cestaKObrazku = HlavniOkno.class.getResource("/obrazky/" + jmenoSouboru);
        if (cestaKObrazku == null) {
            System.out.println("nenalezen obrázek " + jmenoSouboru);
            return new ImageIcon();
        }
        else {
            return new ImageIcon(cestaKObrazku);
        }       
    }   
//    /**
//     * Vytvoří panel v levé části a vloží obrázek
//     * @return 
//     */
//    private JPanel levyPanel() {
//        JPanel panel = new JPanel();
//        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
//        URL cestaKObrazku = HlavniOkno.class.getResource(
//                "/obrazky/kral_hradu.jpg");
//        if (cestaKObrazku != null) {
//            JLabel obrazek = new JLabel(new ImageIcon(cestaKObrazku));
//            panel.add(Box.createGlue());
//            panel.add(obrazek);
//            panel.add(Box.createGlue());
//            panel.setBackground(new Color(30, 30, 30));
//        }
//        else {
//            JLabel chyba = new JLabel("nenašel se obrázek Krále");
//            chyba.setBackground(Color.red);
//            panel.add(chyba);
//        }
//        
//        return panel;
//    }
    /**
     * Vnitřní třída implementující ActionListener slouží ke zpracování příkazu zadaného uživatelem
     */
    private class OvladacLog implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            oknoLogger.setVisible(true);
        }
        
    }
    /**
     * Vnitřní třída implementující ActionListener slouží k ukončení dialogového okna
     */
    
    class konecaction implements ActionListener{
        public void actionPerformed (ActionEvent e){
            System.exit(0);
            EasyLogger.close();
            
        }
    }
    /**
     * Vnitřní třída implementující ActionListener slouží ke spuštění nové hry
     */
    class startaction implements ActionListener{
        public void actionPerformed (ActionEvent e){
            int novaHraOtazka = JOptionPane.showConfirmDialog(null, "Opravdu chcete začít novou hru?");
                   
            hra = new Hra();
            panelVychodu.setEnabled(true);
            hra.getHerniPlan().zaregistruj(panelVychodu);
            //hra.getHerniPlan().zaregistruj(new ZmenaPopisuProstoru());
            hra.getHerniPlan().zaregistruj(mujPlanek);
            panelBatohu.aktualizuj(hra.getHerniPlan().getBatoh());
            hra.getHerniPlan().getBatoh().zaregistrujPredplatitele(panelBatohu);
            vypis.setText(hra.vratUvitani());
            vstupPrikazu.setEnabled(true);
            vypisAndLog(hra.vratUvitani());
            vstupPrikazu.requestFocus();
            konec.setEnabled(true);
            tlacitkoKonec.setEnabled(true);
            panelVychodu.setEnabled(true);
            
            
        }
    }
    /**
     * Vnitřní třída implementující ActionListener slouží k zobrazení okna nápovědy
     */
    private class Napoveda implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent arg0) {
            oknoNapovedy = new OknoNapovedy("/obrazky/napoveda.htm");
            oknoNapovedy.setVisible(true);
            
        }
    }
    /**
     * Ovladač vstupní řádky, do které se vypisuje např. "kralovo_komnata"
     */
    private class OvladacVstupniRadky implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            zpracovaniRadku(vstupPrikazu.getText());
        }       
    }
    /**
     * Ovladač tlačítka pro ukončení
     */
    private class ObsluhaTlacitkaKonec implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            zpracovaniRadku("konec");
        }       
    }
    
        void zpracovaniRadku(String radek) {
        vypis.append("\n> ");
        vypis.append(radek);
        vypis.append("\n");
        String vysl = hra.zpracujPrikaz(radek);
        zobrazeniLogu("\n" + "\n");
        zobrazeniLogu("> " + radek + "\n");
        zobrazeniLogu(vysl);
        vypis.append(vysl);
        vstupPrikazu.setText("");
        if (hra.konecHry()) {
            vypis.append("\n");
            vstupPrikazu.setEnabled(false);
            tlacitkoKonec.setEnabled(false);
            panelVychodu.setEnabled(false);
            zobrazeniLogu(hra.vratUvitani());
        }
        vypis.setCaretPosition(vypis.getText().length());
    }
        /**
         * Metoda zviditelňující hlavníOkno
         * @param visible 
         */
    public void setVisible(boolean visible) {
        hlOkno.setVisible(visible);
    }
    /**
     * Metoda, která vypisuje do logu
     * @param line 
     */
    void vypisAndLog(String line) {
        vypis.append(line);
        EasyLogger.appendText(line);
    }
}