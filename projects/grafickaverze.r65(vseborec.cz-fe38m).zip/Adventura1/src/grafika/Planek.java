
  
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grafika;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import logika.Prostor;

/**
 *
 * @author xmazs03
 */
public class Planek extends JComponent implements PredplatitelZmenyAktualnihoProstoru{

    private Icon planekIcon;
    private Icon panacekIcon;
    private Prostor aktProstor;
    private HlavniOkno grafika;
    
    public Planek(HlavniOkno grafika) {
        this.grafika = grafika;
        planekIcon = createIcon("Adventura jpg.png");
        //panacekIcon = createIcon("panacek.png");
        
        this.setPreferredSize(new Dimension(
                planekIcon.getIconWidth(),
                planekIcon.getIconHeight()));
        //this.addMouseListener(new OvladacMysi());
    }
    /**
     * Metoda vykreslí plánek v hlavním Okně
     * @param g 
     */
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        planekIcon.paintIcon(this, g, 0, 0);
        if (aktProstor != null) {
            if(aktProstor.getNazev().equals("prijezdova_cesta")){
                g.setColor(Color.red);
                g.fillOval(210,220, 15, 15);
            }
             if (aktProstor.getNazev().equals("mistnost_s_drakem")){
                g.setColor(Color.red);
                g.fillOval(90, 70, 15, 15);
               
            }
             if (aktProstor.getNazev().equals("tajemna_komnata")){
                g.setColor(Color.red);
                g.fillOval(190, 70, 15, 15);
             }
             if (aktProstor.getNazev().equals("kralovo_komnata")){
                g.setColor(Color.red);
                g.fillOval(50, 170, 15, 15);
             }
             if (aktProstor.getNazev().equals("mistnost_s_pokladem")){
                g.setColor(Color.red);
                g.fillOval(90, 370, 15, 15);
             }
             if (aktProstor.getNazev().equals("nadvori")){
                g.setColor(Color.red);
                g.fillOval(180, 130, 15, 15);
             }   
        }
    }
    
    
     private Icon createIcon(String jmenoSouboru) {
        URL cestaKObrazku = HlavniOkno.class.getResource("/obrazky/" + jmenoSouboru);
        if (cestaKObrazku == null) {
            return new ImageIcon();
        }
        else {
            return new ImageIcon(cestaKObrazku);
        }       
    }    
    /**
     * Metoda aktualizuje plánek podle prostoru ve kterém se hřáč nachází
     * @param aktProstor 
     */
    @Override
    public void update(Prostor aktProstor) {
//        System.out.println(aktProstor.getNazev());
        this.aktProstor = aktProstor;
        this.repaint();
         }
    /**
     * Metoda pro pohyb po plánku pouhým kliknutím do plánku
     * V této hře není ovladač použit!!
     */
//    private class OvladacMysi implements MouseListener {
//
//        @Override
//        public void mouseClicked(MouseEvent e) {
//            System.out.println("mouseClicked"+e.getX()+ " " + e.getY());
//            if (e.getX() >= 5&& e.getX()<50 && e.getY() >=20 && e.getY() <70 ){
//                grafika.zpracovaniRadku("jdi nadvori");
//            }
//        }
//        
//
//        @Override
//        public void mousePressed(MouseEvent e) {
//        }
//
//        @Override
//        public void mouseReleased(MouseEvent e) {
//        }
//
//        @Override
//        public void mouseEntered(MouseEvent e) {
//        }
//
//        @Override
//        public void mouseExited(MouseEvent e) {
//        }
//        
//    }
}
