/*
 * Tato třída představuje zpřístupnění, vyvolání okna loggeru umístěného v menu.
 * Třída je součástí balíčku grafika
 */
package grafika;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import start.EasyLogger;

/**
 *
 * @author Štěpán Mazanec
 */
public class OknoLogger {
    
    private JDialog oknoLogger;
    private JTextArea textArea;
    
    public OknoLogger () {
        initOknoLogger();
    }
    /**
     * Metoda inicializující okno logerru
     */
    private void initOknoLogger() {
        oknoLogger = new JDialog();
        oknoLogger.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
        oknoLogger.setLayout(new BorderLayout());
        oknoLogger.setTitle("Průběh hry");
        
        textArea = new JTextArea();
        textArea.setEditable(false);
        oknoLogger.add(new JScrollPane(textArea));
        textArea.setText(EasyLogger.getLogContent());
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        oknoLogger.setResizable(false);
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);
        textArea.setFont(new Font("Courier New", Font.BOLD, 14));
        oknoLogger.setLocation(300, 150);
        oknoLogger.setSize(400,600);
    }
    
    
    /**
     *Metoda pro nastavení viditelnosti okna logu
     * @param viditelnost
     */
    public void setVisible(boolean viditelnost) {
        if (viditelnost)  {
            textArea.setText(EasyLogger.getLogContent());
        }
        oknoLogger.setVisible(viditelnost);
    }
}
