/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grafika;
import logika.Batoh;

/**
 *
 * @author stefix
 */
public interface PredplatitelZmenyBatohu {
    
   public void aktualizuj(Batoh batoh);
}
