/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grafika;

import logika.Prostor;

/**
 *Metoda aktualizující místnosti, použito s observer
 * @author xmazs03
 */
public interface PredplatitelZmenyAktualnihoProstoru {
    
    public void update(Prostor aktProstor);
    
}
