package grafika;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import logika.Prostor;

/**
 *
 * @author xmazs03
 */
public class PanelVychodu extends JPanel implements  PredplatitelZmenyAktualnihoProstoru {
    
//    private JTextArea vychodyTextArea;
    
    private JList<String> vychodyList;
    private DefaultListModel<String> vychodyModel;
    private HlavniOkno hlOkno;
    
    public PanelVychodu(HlavniOkno hlOkno){
        this.hlOkno = hlOkno;
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JLabel popisek = new JLabel("východy:");
        this.add(popisek);
        
        vychodyModel = new DefaultListModel<>();
        vychodyList = new JList<>(vychodyModel);
        this.add(vychodyList);
        
        vychodyList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        vychodyList.addListSelectionListener(new VyberVychodu());
               
//        
//        vychodyTextArea = new JTextArea(5, 8);
//        this.add(vychodyTextArea);
//        vychodyTextArea.setEditable(false);
    }

    @Override
    public void update(Prostor aktProstor) {
        vychodyModel.removeAllElements();
        for (Prostor soused : aktProstor.getVychody()) {
            vychodyModel.addElement((soused.getNazev()));
        }
        
//        vychodyTextArea.setText("");
//        for(Prostor soused: aktProstor.getVychody()){
//            vychodyTextArea.append(soused.getNazev());
//            vychodyTextArea.append("\n");
//        }
        
    }
    
    private class VyberVychodu implements ListSelectionListener {

        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (e.getValueIsAdjusting() == false) {
                if (vychodyList.getSelectedIndex() >=0 ) {
                    String jmeno = vychodyList.getSelectedValue();
                    hlOkno.zpracovaniRadku ("jdi " + jmeno);
                 }
            }
        }
        
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        vychodyList.setEnabled(enabled);
    }
    
    
    
}
