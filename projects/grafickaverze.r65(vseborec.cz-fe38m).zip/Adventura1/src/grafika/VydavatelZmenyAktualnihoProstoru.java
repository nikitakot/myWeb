/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grafika;

/**
 *
 * @author xmazs03
 */
public interface VydavatelZmenyAktualnihoProstoru {
    public void zaregistruj(PredplatitelZmenyAktualnihoProstoru predplatitel);
    
    public void odregistruj(PredplatitelZmenyAktualnihoProstoru predplatitel);
    
    public void upozorniPredplatitele();
    
}
