/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grafika;

/**
 *
 * @author stefix
 */
public interface VydavatelZmenyBatohu {
    
public void zaregistrujPredplatitele(PredplatitelZmenyBatohu predplatitel);
public void odregistrujPredplatitele(PredplatitelZmenyBatohu predplatitel);
public void upozorniPredplatiteleBatohu();
            
}
