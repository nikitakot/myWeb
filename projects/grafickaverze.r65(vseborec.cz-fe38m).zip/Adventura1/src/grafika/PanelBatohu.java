/*
 * Třída implementuje panelBatohu do adventury, metoda vykresluje obrázky sebraných
 * věcí a vložených do batohu
 */
package grafika;

import java.util.HashMap;
import javax.swing.Icon;
import javax.swing.JPanel;
import logika.Batoh;
import logika.Vec;
import java.awt.Graphics;
import java.net.URL;
import javax.swing.ImageIcon;
import grafika.PredplatitelZmenyBatohu;

/**
 *
 * @author stefix
 */
public class PanelBatohu extends JPanel implements PredplatitelZmenyBatohu {
    
    
    private Icon vecIcon;
    private HashMap<String, Vec> seznamVeci;
    
    public PanelBatohu(Batoh bato){
        bato.zaregistrujPredplatitele(this);
    }
    
    /**
     * Metoda aktualizuje seznam věcí v batohu
     * @param batoh 
     */
    @Override
    public void aktualizuj(Batoh batoh) {
        seznamVeci = batoh.seznamPredmetu();
        revalidate();
        repaint();
    }
    /**
     * Metoda vykreslí obrázky sebraných věcí.
     * @param g 
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        int horni = 15;
        URL umisteniObrazku;
        for (String nazev : seznamVeci.keySet()) {
//            System.out.println(nazev);
            umisteniObrazku = this.getClass().getResource("/obrazky/" + nazev + ".jpg");
            if (umisteniObrazku !=null) {
                vecIcon = new ImageIcon(umisteniObrazku);
                if (vecIcon != null) {
                    vecIcon.paintIcon(this, g, horni, horni);
                    horni += vecIcon.getIconHeight();
                }
            }
        }
    }
    
}
