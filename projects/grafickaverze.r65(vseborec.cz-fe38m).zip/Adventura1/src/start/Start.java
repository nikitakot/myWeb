package start;

import grafika.HlavniOkno;
import text.TextoveRozhrani;
import grafika.HlavniOkno;
import java.io.IOException;
/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */

/*******************************************************************************
 * Instance třídy Start představují ...
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class Start
{
    public static void main(String[] args) throws IOException
    {
        
        EasyLogger.init("Log.txt");
        HlavniOkno grafika = new HlavniOkno();
        grafika.setVisible(true);
//        TextoveRozhrani rozhrani = new TextoveRozhrani();
//        if(args.length==0){
//            rozhrani.hraj();
//        }
//        else
//        {
//            rozhrani.hrajZeSouboru(args[0]);
//        }
////        
//        HlavniOkno grafika = new HlavniOkno();
//
//        grafika.setVisible(true);
    }
}
