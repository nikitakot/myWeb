/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Stefix
 */
public class EasyLogger {
    
    private static PrintWriter pw;
    private static StringBuilder logContent;
    
    public static void init(String path) throws IOException {
        File f = new File(path);
        f.delete();
        
        pw = new PrintWriter(path);
        logContent = new StringBuilder();
    }
    
    
    public static void appendText (String line) {
        pw.append(line);
        pw.flush();
        logContent.append(line);
    }
    
    public static void appendLine (String line) {
        pw.append(line);
        pw.append("\n");
        pw.flush();
        logContent.append(line);
        logContent.append("\n");
    }
    
    public static void close() {
        pw.flush();
        pw.close();
    }
    
    public static String getLogContent(){
        return logContent.toString();
    }
}
