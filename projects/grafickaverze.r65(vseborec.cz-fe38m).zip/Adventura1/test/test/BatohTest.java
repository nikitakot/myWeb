package test;

import logika.Batoh;
import logika.Vec;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Testovací třída BatohTest slouží ke komplexnímu otestování třídy Batoh
 * 
 *
 * @author    Štěpán Mazanec
 * @version   1.00.000
 */
public class BatohTest {

    /**
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * přípravek (fixture), což je sada objektů, s nimiž budou testy pracovat.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Testuje vkládání věcí do batohu
     *
     */
    @Test
    public void testVkladaniDoBatohu()
    {
        Batoh batoh1 = new Batoh();
        Vec vec1 = new Vec("a", true, true);
        assertEquals(true, batoh1.vlozVec(vec1));
        assertEquals(true,batoh1.obsahujeVec("a"));
    }

    /**
     * Testuje odstaňování věcí z batohu
     *
     */
    @Test
    public void testOdhozeniZBatohu()
    {
        Batoh batoh1 = new Batoh();
        Vec vec1 = new Vec("a", true, true);
        assertEquals(true, batoh1.vlozVec(vec1));
        assertEquals(true, batoh1.odlozVec("a"));
        assertEquals(false, batoh1.obsahujeVec("a"));
    }

    /**
     * Testuje kapacitu batohu
     *
     */
    @Test
    public void testMaxPocetVBatohu()
    {
        Batoh batoh1 = new Batoh();
        Vec vec1 = new Vec("a", true, true);
        Vec vec2 = new Vec("b", true, true);
        Vec vec3 = new Vec("c", true, true);
        Vec vec4 = new Vec("d", true, true);
        assertEquals(true, batoh1.vlozVec(vec1));
        assertEquals(true, batoh1.vlozVec(vec2));
        assertEquals(true, batoh1.vlozVec(vec3));
        assertEquals(false, batoh1.vlozVec(vec4));
    }
}

