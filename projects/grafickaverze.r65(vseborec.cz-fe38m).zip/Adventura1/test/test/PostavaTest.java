package test;

import logika.Postava;
import logika.Prostor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Testovací třída PostavaTest slouží ke komplexnímu otestování třídy Postava
 * 
 *
 * @author    štěpán Mazanec
 * @version   1.00.000
 */
public class PostavaTest {

    /**
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * přípravek (fixture), což je sada objektů, s nimiž budou testy pracovat.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Testuje vkládání věci do věci
     *
     */
    @Test
    public void testPostava()
    {
        Postava postava1 = new Postava ("1","");
        Prostor mistnost1 = new Prostor("mistnost1","");
        mistnost1.vlozPostavu(postava1);
        assertEquals(postava1, mistnost1.existujePostava("1"));
        assertEquals(null, mistnost1.existujePostava("2"));
    }
}

