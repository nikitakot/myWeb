package test;

import logika.Vec;
import logika.Prostor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Testovací třída ProstorTest slouží ke komplexnímu otestování třídy Prostor
 * 
 *
 * @author    Jarmila Pavlíčková, Štěpán Mazanec
 * @version   pro skolní rok 2012/2013
 */
public class ProstorTest{


    /**
     * Metoda se provede před spuštěním každé testovací metody. Používá se
     * k vytvoření tzv. přípravku (fixture), což jsou datové atributy (objekty),
     * s nimiž budou testovací metody pracovat.
     */
    @Before
    public void setUp() {
    }

    /**
     * Úklid po testu - tato metoda se spustí po vykonání každé testovací metody.
     */
    @After
    public void tearDown() {
    }

    /**
     * Testuje, zda jsou správně nastaveny průchody mezi prostory hry.
     */
    @Test
    public  void testLzeProjit() {
        
        Prostor mistnost1 = new Prostor("mistnost1", "");
        Prostor mistnost2 = new Prostor("mistnost2", "");
        mistnost1.setVychod(mistnost2);
        mistnost2.setVychod(mistnost1);
        assertEquals(mistnost2, mistnost1.vratSousedniProstor("mistnost2"));
        assertEquals(null, mistnost2.vratSousedniProstor("another"));      
    }
    
    /**
     * Testuje zda jde sebrat věc v prostoru.
     */
    @Test
    public void testVeci()
    {
        Prostor mistnost1 = new Prostor("mistnost1", "");
        Vec vec1 = new Vec("1", true, true);
        Vec vec2 = new Vec("2", false, true);
        assertEquals(true, mistnost1.vlozVec(vec1));
        assertEquals(true, mistnost1.vlozVec(vec2));
        assertEquals(true, mistnost1.obsahujeVec("1"));
        assertEquals(false, mistnost1.obsahujeVec("3"));
        assertNotNull(mistnost1.seberVec("1"));
        assertNull(mistnost1.seberVec("2"));
        assertNull(mistnost1.seberVec("3"));
    }
    
    /**
     * Testuje nastavené klíče prostoru
     */
    @Test
    public void testKlic()
    {
        Vec vec1 = new Vec("1",true,true);
        Prostor mistnost1 = new Prostor("tady","");
        mistnost1.setZamcena(true);
        mistnost1.setKlic(vec1);
        assertEquals(vec1, mistnost1.getKlic());
    }
}
