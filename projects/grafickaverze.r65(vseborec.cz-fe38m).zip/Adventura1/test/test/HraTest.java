package test;

import logika.Hra;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Testovací třída HraTest slouží ke komplexnímu otestování třídy Hra
 * Byla rozdělena do několika metod, pro testování místnosti smrti, atd.
 *
 * @author   Jarmila Pavlíčková, Štěpán Mazanec
 * @date     30.12.2012
 * @version  pro školní rok 2012/2013
 */
public class HraTest {
    private Hra hra1;

    /**
     * Metoda se provede před spuštěním každé testovací metody. Používá se
     * k vytvoření tzv. přípravku (fixture), což jsou datové atributy (objekty),
     * s nimiž budou testovací metody pracovat.
     */
    @Before
    public void setUp() {
        hra1 = new Hra();
    }

    /**
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Testuje průběh ukončení hry. Hra disponuje několika možnostmi smrti a následného ukončení hry.
     * Hráč může hru ukončit příkazem konec, nebo vstoupit do tvou smrtelných místností.
     */
    @Test
    public void testMoznostiSmrti(){
        hra1.zpracujPrikaz("konec");
        assertEquals(true, hra1.konecHry());
        hra1.zpracujPrikaz("jdi tajemna_komnata");
        assertEquals(true, hra1.konecHry());
//        hra1.zpracujPrikaz("jdi nouzovyvychod");
//        assertEquals(true, hra1.konecHry());
    }

    /**
     * Kontroluje nemožnost vzít do batohu nepřenositelnou věc
     * 
     */
    @Test
    public void testNeprenositelnostVeci(){
        assertEquals("prijezdova_cesta", hra1.getHerniPlan().getAktualniProstor().getNazev());
        hra1.zpracujPrikaz("jdi nadvori");
        hra1.zpracujPrikaz("jdi kralovo_komnata");
        hra1.zpracujPrikaz("seber klicA");
        hra1.zpracujPrikaz("jdi nadvori");
        hra1.zpracujPrikaz("odemkni mistnost_s_truhlou");
        hra1.zpracujPrikaz("jdi mistnost_s_truhlou");
        hra1.zpracujPrikaz("seber truhla");
        assertFalse(hra1.getHerniPlan().getBatoh().obsahujeVec("truhla"));

    }

    /**
     * Testuje průběh hry, po zavolání každěho příkazu testuje, zda hra končí
     * a v jaké aktuální místnosti se hráč nachází.
     */
    @Test
    public void testPrubehHry() {
        assertEquals("prijezdova_cesta", hra1.getHerniPlan().getAktualniProstor().getNazev());
        hra1.zpracujPrikaz("jdi nadvori");
        hra1.zpracujPrikaz("jdi kralovo_komnata");
        hra1.zpracujPrikaz("mluv kral");
        hra1.zpracujPrikaz("seber klicA");
        assertTrue(hra1.getHerniPlan().getBatoh().obsahujeVec("klicA"));
        hra1.zpracujPrikaz("jdi nadvori");
        hra1.zpracujPrikaz("odemkni mistnost_s_truhlou");
        hra1.zpracujPrikaz("jdi mistnost_s_truhlou");
        hra1.zpracujPrikaz("prohledat truhla");
        hra1.zpracujPrikaz("seber mec");
        assertTrue(hra1.getHerniPlan().getBatoh().obsahujeVec("mec"));
        hra1.zpracujPrikaz("jdi nadvori");
        hra1.zpracujPrikaz("jdi mistnost_s_drakem");
        hra1.zpracujPrikaz("zabij drak");
        assertTrue(hra1.getHerniPlan().getBatoh().obsahujeVec("klicB"));
        hra1.zpracujPrikaz("jdi nadvori");
        hra1.zpracujPrikaz("odemkni mistnost_s_pokladem");
        hra1.zpracujPrikaz("jdi mistnost_s_pokladem");
        assertEquals(true,hra1.konecHry());
    }
}
