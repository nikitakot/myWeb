/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import logika.HerniPlan;
import logika.Prostor;
import util.Observer;

/**
 * Okno zobrazující mapu a řádek s aktuálním prostorem
 *
 * @author Filip Gregor
 */
public class OknoProstoru extends JComponent implements Observer {

    JTextField popisMapyTextField;
    HerniPlan plan;
    ImageIcon mapaIcon;
    JLabel obrazekLabel;
    JFrame oknoProstoruFrame;
    JPanel obrazekMapyPanel;
    private Dimension souradnice;

    /**
     * koňstruktor - herní plán nastaví samostatnou metodou
     *
     * @param plan - herní plán
     */
    OknoProstoru(HerniPlan plan) {
        super();
        init();
        nastaveniHernihoPlanu(plan);
    }

    /**
     * inicializační metoda
     */
    private void init() {
        oknoProstoruFrame = new JFrame();
        oknoProstoruFrame.setDefaultCloseOperation(0);
        oknoProstoruFrame.setTitle("mapa");
        oknoProstoruFrame.setSize(640, 640);
        obrazekMapyPanel = new JPanel();
        
        popisMapyTextField = new JTextField();
        popisMapyTextField.setEditable(false);

        oknoProstoruFrame.add(obrazekMapyPanel);
        oknoProstoruFrame.add(popisMapyTextField, BorderLayout.SOUTH);

        URL umisteniObrazku = this.getClass().getResource("/zdroje/mapNull.gif");
        if (umisteniObrazku == null) {
            JOptionPane.showMessageDialog(null, "Soubor s obrázkem nebyl nalezen", "Chyba při načítání obrázku", JOptionPane.ERROR_MESSAGE);
        } else {
            mapaIcon = new ImageIcon(umisteniObrazku);
            obrazekLabel = new JLabel(mapaIcon);
            
            obrazekMapyPanel.add(obrazekLabel);
        }
        oknoProstoruFrame.setVisible(true);
    }

    /**
     * V zadání bylo aby se na mapě kreslil bod či něco podobného podle toho, ve
     * kterém prostoru se nacházím. to mám naimplementováno, logika mé
     * implementace je správná, nicméně mi to nefunguje. Tahle metoda je
     * připravená na zprovoznění
     *
     * @param g - grafika
     */
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        mapaIcon.paintIcon(this, g, 0, 0);
        
        souradnice = plan.getAktualniProstor().getPoziceZnacky();
        g.setColor(Color.orange);
        g.drawLine(souradnice.width - 20, souradnice.height - 20, souradnice.width + 20, souradnice.height + 20);
        g.drawLine(souradnice.width + 20, souradnice.height - 20, souradnice.width - 20, souradnice.height + 20);
        g.fillOval(souradnice.width, souradnice.height, 20, 20);
    }

    /**
     * metoda nastaví herní plán
     *
     * @param plan - tadydleten
     */
    public void nastaveniHernihoPlanu(HerniPlan plan) {
        this.plan = plan;
        plan.zaregistrujPozorovatele(this);
        this.aktualizuj(plan.getAktualniProstor());
    }

    /**
     * A tohle to celé okno aktualizuje - překrytá metoda z Observeru
     *
     * @param aktualniProstor - aktuální prostor
     */
    @Override
    public void aktualizuj(Prostor aktualniProstor) {
        popisMapyTextField.setText("Jsi v prostoru " + plan.getAktualniProstor().getNazev());
        mapaIcon = plan.getAktualniProstor().getSouborMapy();
        obrazekLabel.setIcon(mapaIcon);
        obrazekLabel.repaint();
    }
}
