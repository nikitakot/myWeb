/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import java.awt.Dimension;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import logika.HerniPlan;
import logika.Prostor;
import util.Observer;

/**
 * Panel zobrazující list s východy vpravo
 *
 * @author xgref01
 */
public class PanelVychodu extends JPanel implements Observer {

    private HerniPlan plan;
    private JTextArea seznamVychoduTextArea;
    private DefaultListModel model;
    private JList vychodyList;
    private Gui gui;

    /**
     * Konstruktor, který inicializuje panel, zaregistruje ho jako pozorovatele
     * u herního plánu
     *
     * @param plan herní plán
     */
    public PanelVychodu(HerniPlan plan) {
        super();
        init();
        nastaveniHernihoPlanu(plan);
    }

    /**
     * nastavení herního plánu
     *
     * @param plan - tohohle
     */
    public void nastaveniHernihoPlanu(HerniPlan plan) {
        this.plan = plan;
        plan.zaregistrujPozorovatele(this);     // třída se zaregistruje jako pozorovatel změny prostoru
        this.aktualizuj(plan.getAktualniProstor());    // zobrazí se východy aktuální o prostoru   
    }

    /**
     * A listener pro list
     */
    private class VyberVychodu implements ListSelectionListener {

        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting() && vychodyList.getSelectedIndex() != -1) {
                String vychod = (String) vychodyList.getSelectedValue();
                gui.zpracujPrikaz("jdi " + vychod);

            }

        }
    }

    /**
     * Metoda pro inicializaci komponent panelu.
     */
    private void init() {

        model = new DefaultListModel();
        vychodyList = new JList(model);
        vychodyList.setPreferredSize(new Dimension(100, 500));
        vychodyList.setBorder(new TitledBorder("Východy"));
        vychodyList.addListSelectionListener(new VyberVychodu());

        this.add(vychodyList);
    }

    /**
     * nastavení Gui, kam se posílají příkazy z listeneru
     *
     * @param gui - gui
     */
    public void setGui(Gui gui) {
        this.gui = gui;
    }

    /**
     * metoda pro aktulizaci panelu - je volána při změně subjektu
     */
    @Override
    public void aktualizuj(Prostor aktualniProstor) {

        model.removeAllElements();
        for (Prostor i : plan.getAktualniProstor().getVychody()) {
            model.addElement(i.getNazev());
        }
    }
}
