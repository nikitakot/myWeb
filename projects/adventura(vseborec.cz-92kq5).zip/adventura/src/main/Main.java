package main;

import logika.Hra;
import ui.Gui;
import ui.TextoveRozhrani;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Třída Main slouží ke spouštění aplikace ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
public class Main {

    /**
     * *************************************************************************
     * Metoda, prostřednictvím níž se spouští celá aplikace.
     *
     * @param args Parametry příkazového řádku
     */
    public static void main(String[] args) {
        TextoveRozhrani rozhrani = new TextoveRozhrani();
        if (args.length == 0) {
            Gui grafika = new Gui(new Hra());
            grafika.setVisible(true);
        } else {
            if (args[0].equals("text")) {
                rozhrani.hraj();
            } else {
                rozhrani.hrajSoubor(new java.io.File(args[0]));
            }
        }
    }

}
