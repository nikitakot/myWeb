package logika;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import util.Observer;
import util.SubjektObserveru;

/**
 * Třída Hra - třída představující logiku adventury.
 *
 * Toto je hlavní třída logiky aplikace. Tato třída vytváří instanci třídy
 * HerniPlan, která inicializuje mistnosti hry a vytváří seznam platných příkazů
 * a instance tříd provádějící jednotlivé příkazy. Vypisuje uvítací a ukončovací
 * text hry. Také vyhodnocuje jednotlivé příkazy zadané uživatelem.
 *
 * @author Michael Kolling, Lubos Pavlicek, Jarmila Pavlickova
 * @version pro školní rok 2013/2014
 */
public class Hra implements SubjektObserveru {

    private List<Observer> seznamPozorovatelu;

    private SeznamPrikazu platnePrikazy;    // obsahuje seznam přípustných příkazů
    private HerniPlan herniPlan;
    private boolean konecHry = false;
    private String epilog = "Dík, že jste si zahráli.  Ahoj.";

    private KamenNuzkyPapir kaNuPa;
    private Verse verse;

    /**
     * Vytváří hru a inicializuje místnosti (prostřednictvím třídy HerniPlan) a
     * seznam platných příkazů.
     */
    public Hra() {

        herniPlan = new HerniPlan();
        Inventar inventar = new Inventar(herniPlan, 4);
        herniPlan.setInventar(inventar);
        platnePrikazy = new SeznamPrikazu();
        platnePrikazy.vlozPrikaz(new PrikazNapoveda(platnePrikazy));
        platnePrikazy.vlozPrikaz(new PrikazJdi(herniPlan));
        platnePrikazy.vlozPrikaz(new PrikazKonec(this));
        platnePrikazy.vlozPrikaz(new PrikazSeber(herniPlan, inventar));
        platnePrikazy.vlozPrikaz(new PrikazZahod(herniPlan, inventar));
        platnePrikazy.vlozPrikaz(new PrikazInventar(inventar));
        platnePrikazy.vlozPrikaz(new PrikazPouzij(herniPlan, inventar));
        platnePrikazy.vlozPrikaz(new PrikazCojeto(herniPlan, inventar));
        platnePrikazy.vlozPrikaz(new PrikazKdejsem(herniPlan));

        kaNuPa = new KamenNuzkyPapir(herniPlan);
        verse = new Verse(herniPlan);
    }

    /**
     * Vrátí úvodní zprávu pro hráče.
     *
     * @return text uvítání
     */
    public String vratUvitani() {
        return Texty.UVITANI.getText()
                + herniPlan.getAktualniProstor().dlouhyPopis();
    }

    /**
     * Vrátí závěrečnou zprávu pro hráče.
     *
     * @return text epilogu
     */
    public String vratEpilog() {
        return epilog;
    }

    /**
     * Vrací true, pokud hra skončila.
     *
     * @return je konec hry?
     */
    public boolean konecHry() {
        return konecHry;
    }

    /**
     * Metoda zpracuje řetězec uvedený jako parametr, rozdělí ho na slovo
     * příkazu a další parametry. Pak otestuje zda příkaz je klíčovým slovem
     * např. jdi. Pokud ano spustí samotné provádění příkazu.
     *
     * @param radek text, který zadal uživatel jako příkaz do hry.
     * @return vrací se řetězec, který se má vypsat na obrazovku
     */
    public String zpracujPrikaz(String radek) {
        String[] slova = radek.split(" ");

        if ((herniPlan.getMinihra() == null)) {
            String slovoPrikazu;
            try {
                slovoPrikazu = slova[0];
            } catch (ArrayIndexOutOfBoundsException e) {
                return "Nic nebylo zadáno.";
            }
            String[] parametry = new String[slova.length - 1];
            for (int i = 0; i < parametry.length; i++) {
                parametry[i] = slova[i + 1];
            }
            String textKVypsani = "______________________________________________________________\n";

            if (platnePrikazy.jePlatnyPrikaz(slovoPrikazu)) {
                IPrikaz prikaz = platnePrikazy.vratPrikaz(slovoPrikazu);
                textKVypsani += prikaz.proved(parametry);
                upozorniPozorovatele();

            } else {
                textKVypsani += "Nevím co tím myslíš? Tento příkaz neznám. ";
            }
            if (herniPlan.getVyhra()) {
                konecHry = true;
                epilog = herniPlan.getZpravaNaKonec();
            }
            if (herniPlan.getProhra()) {
                konecHry = true;
                epilog = herniPlan.getZpravaNaKonec();
            }
            return textKVypsani;
        } else {
            if (herniPlan.getMinihra().equals("KNP")) {
                return kaNuPa.proved(slova);
            }
            if (herniPlan.getMinihra().equals("Vers")) {
                return verse.proved(slova);
            } else {
                herniPlan.setMinihra(null);
                return "Hra nenalezena";
            }
        }
    }

    /**
     * Nastaví, že je konec hry, metodu využívá třída PrikazKonec, mohou ji
     * použít i další implementace rozhraní Prikaz.
     *
     * @param konecHry hodnota false= konec hry, true = hra pokračuje
     */
    void setKonecHry(boolean konecHry) {
        this.konecHry = konecHry;
    }

    /**
     * Metoda vrátí odkaz na herní plán, je využita hlavně v testech, kde se
     * jejím prostřednictvím získává aktualní místnost hry.
     *
     * @return odkaz na herní plán
     */
    public HerniPlan getHerniPlan() {
        return herniPlan;
    }

    public void zaregistrujPozorovatele(Observer pozorovatel) {
        seznamPozorovatelu.add(pozorovatel);
    }

    public void odregistrujPozorovatele(Observer pozorovatel) {
        seznamPozorovatelu.remove(pozorovatel);
    }

    public void upozorniPozorovatele() {
        herniPlan.upozorniPozorovatele();
    }

}
