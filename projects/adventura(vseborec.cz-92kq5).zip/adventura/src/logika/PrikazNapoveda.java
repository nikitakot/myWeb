package logika;

/**
 * Třída PrikazNapoveda implementuje pro hru příkaz napoveda. Tato třída je
 * součástí jednoduché textové hry.
 *
 * @author Jarmila Pavlickova, Luboš Pavlíček
 * @version pro školní rok 2013/2014
 *
 */
class PrikazNapoveda implements IPrikaz {

    private static final String NAZEV = "napoveda";
    private SeznamPrikazu platnePrikazy;

    /**
     * Konstruktor třídy
     *
     * @param platnePrikazy seznam příkazů, které je možné ve hře použít, aby je
     * nápověda mohla zobrazit uživateli.
     */
    public PrikazNapoveda(SeznamPrikazu platnePrikazy) {
        this.platnePrikazy = platnePrikazy;
    }

    /**
     * Vrací základní nápovědu po zadání příkazu "napoveda". Nyní se vypisuje
     * vcelku primitivní zpráva a seznam dostupných příkazů.
     *
     * @return napoveda ke hre
     */
    @Override
    public String proved(String... parametry) {
        if (parametry.length > 0 && parametry[0].equals("?")) {
            return "Nápověda pro příkaz napoveda: \n"
                    + "Pokud potřebujete poradit, napište tento příkaz.\n"
                    + "Použití: napoveda\n"
                    + "Rovněž Vám blahopřeji, zařadil jste se mezi početnou skupinu hráčů, \n"
                    + "kteří potřebují nápovědu i k nápovědě.";
        }

        return "Tvým úkolem je doručit kufřík kupci.\n"
                + "\n"
                + "Můžeš zadat tyto příkazy:\n"
                + platnePrikazy.vratNazvyPrikazu() + "\n \n"
                + "Pokud potřebujete nápovědu ke konkrétnímu příkazu,\n"
                + "zadejte do jeho parametrů ? - např. 'napoveda ?'";
    }

    /**
     * Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *
     * @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }

}
