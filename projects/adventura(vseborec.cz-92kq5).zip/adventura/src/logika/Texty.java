package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance výčtového typu Texty představují ...
 *
 * @author Filip Gregor
 * @version 0.00.000
 */
public enum Texty {
    //== HODNOTY VÝČTOVÉHO TYPU ================================================

    ////=====  Příklad s bezparametrickým konstruktorem  =======================
    //
    ////=====  Příklad s konstruktorem s parametry =============================
    //     JARO(par), LETO(par), PODZIM(par), ZIMA(par);
    UVITANI("Vítejte!\n"
            + "Čekání na Godota, verze 2.3\n"
            + "exportní verze se super duper neúžasnějším GUI\n"
            + "Napište 'napoveda', pokud si nevíte rady, jak hrát dál.\n"
            + "Pro nápovědu k samotnému příkazu napište název příkazu a ?, 'např. jdi ?'\n"
            + "Pro nápovědu k věci použijte příkaz cojeto (věc)."
            + "\n"
            + "_________________________________________________________________________\n"
            + "Nedávno jsem prohledával byt. A našel jsem ve skříni se starým harampádím\n"
            + "něco z pozůstalosti po mém dědovi.                                       \n"
            + "Starý svícen, konvici, víno (aspoň něco užitečného) a kufřík s jeho věcmi\n"
            + "používanými během jeho kouzelnické kariéry.                              \n"
            + "Konvice se rozbila téměř okamžitě, víno si šetřím na silvestra, svícen   \n"
            + "se bude hodit na zatloukání hřebíků (poctivá litina), kufřík prodám...   \n"
            + "Po chvíli hledání jsem našel ochotného kupce. Ten mi zaplatil a teď už   \n"
            + "zbývá jen doručit zásilku. Máme sraz na nábřeží hned za mým bytem...     \n"
            + "_________________________________________________________________________\n"
            + "Vítejte v této hře. Než opustíte tento byt, chtěl bych Vás ji naučit.\n"
            + "Pokud už jste naučen(a) a chcete návod vynechat, použijte Vypínač.   \n"
            + "Hra obsahuje několik příkazů - 'seber/zahod věc', 'pouzij věc',      \n"
            + "kterým lze použít buď věc samotnou, ale chcete-li například          \n"
            + "odemknout dveře klíčem, můžete rovněž zadat 'pouzij Klíč Dveře' pro  \n"
            + "jejich interakci. Jsou tu i některé speciální předměty, např. hodiny \n"
            + "a také jeden úplně zbytečný předmět. Zkuste například použít Dveře.  \n"
            + "_____________________________________________________________________\n"),
    POKOJ("Jste v pokoji, zde můžete příkazem seber vzít klíč nebo kufřík.\n"
            + "Radím Vám vzít si obojí, jedním odemknete dveře, to druhé máte doručit."),
    PISTOLE("Tento předmět na nic nepotřebuješ, v průběhu hry ho také nikdy nevyužiješ,\n"
            + "ale co by to bylo za hru beze zbraní!"),
    CAJOVNA("Ocitáš se v malebně a trochu tajemně zařízené čajovně.\n"
            + "Za barem barman, kousek dál parta lidí, jeden hraje na kytaru a zbytek setrvává v družném hovoru."),
    VIP("Čajovna má i svou VIP místnost pro nejvěrnější zákazníky. Tam jsi vešel.\n"
            + "V místnosti sedí v tureckém sedu drobný chlapec s hlubokýma očima a trochu neostrými rysy.\n"
            + "Neustále si něco mumlá, ty brzy poznáš, že to je báseň."),
    NABREZI("Páchne to tu rybinou a kachny se jen předhánějí, \n"
            + "aby si zasloužily svou pověst nejhladovějších obyvatel města."),
    POSTA("Nacházíš se před polorozpadlou budovou staré pošty.\n"
            + "Oprýskaná omítka, zaprášená okna a zašlý nápis 'Pošta.' Jo a tramvajová zastávka pár kroků odsud.\n"
            + "Oknem vidíš uvnitř zašlého staříka a na okně nápis Harribatovo vetešnictví."),
    PRAK("Zdobný sošný strohý lepý těžký oblý kovový prak. "
            + "Polovina z těch přívlastků nedává smysl a dva si protiřečí, "
            + "ale nebudeme kazit poetický charakter téhle hry."),
    TEZITKO("Nenápadná skleněná koule, která prý člověku pomůže usměrnit myšlenky. A vypadá jako těžítko."),
    AAKLIC("Výborně! Zvládl jste tutoriál a nyní víte jak hrát.\n"
            + "Pokud chcete znát další možné příkazy, zadejte 'napoveda'.\n"
            + "Nyní odemykám dveře a pouštím Vás z bytu do světa širého.\n"
            + "- nový východ z místnosti - Nábřeží\n"),
    AAPOSTEL("Nic se nestalo - já tam tuhle věc dávat nechtěl, ale brácha trval na tom, \n"
            + "že když jsem zmínil postel v popisu místnosti, tak že ji tam dát musím..."),
    AASTOLEK("Otevírám noční stolek, abych vzápětí našel lehkou dobře přenositelnou pistoli. \n"
            + "(ale na co mi vůbec je?...) - nová věc v místosti - Pistole"),
    AAPISTOLE("\n"
            + "Okolím třeskl výstřel. Ten slyší policista hlídkující v okolí. \n"
            + "Běží směrem k tobě, vytahuje služební zbraň, aby tě přinutil vzdát se, \n"
            + "ale tento stát nemá peníze na pořádný střelecký výcvik pro své policisty, \n"
            + "takže tenhle omylem zmáčkne spoušť a střelí tě rovnou do hlavy.      KONEC HRY"),
    AADVERE("\n"
            + "Dveře jsou ale zamčené, musíte se podívat po klíči. Použijte příkaz jdi\n"
            + "s názvem místnosti, v tomto případě 'jdi Pokoj' nebo 'jdi Ložnice'.    \n"
            + "_______________________________________________________________________\n"),
    AAPAN("Pustíš se k dredatému pánovi, který si tě celou dobu prohlíží.\n"
            + "Ten na tebe už z dálky zavolá: Hej! Vy asi budete čekat na pana Godota!\n"
            + "Řekl mi, že sem přijde někdo jako vy, že pro něj něco máte.\n"
            + "Ale bohužel nemohl dorazit, můžete se podívat tady do čajovny, jestli tam na něj za chvíli nenarazíte.\n"
            + "Než jsi stačil poděkovat, zmizel. Rychleji, než kdyby jen tak odkráčel nebo odběhl...\n"),
    AAKUFR("\n"
            + "'Tak tohle je ten pan vnuk!' Zvolá pan Godot, jen co tě uvidí a narovná si límeček. 'Musíte mě omluvit,\n"
            + "úplně jsem na vás zapomněl.' Bere si kufřík a pokračuje: 'Jestli jsem vám způsobil nějaké trápení,\n"
            + "dovolte abych to odčinil aspoň tak že se připojíte k mým přátelům na naší oslavě.\n"
            + "______________________________________________________________________________________________________________________________\n"
            + "A tak tenhle divný den dostal stejně divný, ale příjemný konec. Godotův parník je prošpikovaný dalšími jeho magickými přáteli.\n"
            + "Atmosféra je kouzelná, z pana Godota se vyklubal velký bonviván, a ty jen zatoužíš dodržet tradici tvého dědečka\n"
            + "a stát se jedním z nich. Pronáší se sliby, přání, přípitky, sázky, sliby, přípitky, smích přípitky...\n"
            + "______________________________________________________________________________________________________________________________\n"
            + "Zkrátka se probudíš ráno ve své posteli, žaludek jakoby se ti mstil, v ústech jako ve výhni, závratě jen co se vzepřeš do sedu,\n"
            + "perly pryč, prak i těžítko také pryč, a ze vzpomínek asi tak tolik, žes včera prodal kufřík,\n"
            + "ale už si vůbec nevzpomeneš, kdes to u všech čertů lítal a cos tam prováděl.                   KONEC HRY\n"
            + "BLAHOPŘEJI K VÝHŘE\n"
            + "PODĚKOVÁNÍ: Janu Gregorovi nejmladšímu a Janě Mádlové za betatest, Janě Mádlové navíc za korektůru návodu"),
    AAZASTN("Tramvaj se za chvíli přišourá ke stanici.\n"
            + "Nastoupíš a rozjedete se stejným tempem pryč,\n"
            + "směrem ke staré poště. Jedete tak dlouho,\n"
            + "až dostaneš strach, že tam kde vystoupíš\n"
            + "už budou tramvajím říkat šaliny.\n"
            + "Ale nakonec zdárně dorazíš ke zchátralé poštovní budově.\n"),
    AAZASTP("Tramvaj se přiřítí ke stanici,\n"
            + "jakoby odsud někam spěchala. Kvapně nastoupíš\n"
            + "a po chvíli v nacpané tramvaji už vidíš nábřeží.\n"),
    AABARMAN1(
            "Rozhlížíš se po čajovně s myšlenkami na onoho dredatého podivína\n"
            + "z nábřeží. Dodáš si odvahu a zamíříš k mohutnému baru a barmana se zeptáš,\n"
            + "jestli něco neví o panu Godotovi. A barman na to že jo! A že se jedná\n"
            + "o jejich stálého hosta. A že prý mívá trochu podivnou klientelu,\n"
            + "'jestli mi prý rozumíte.' Vyzývá tě aby ses posadil, a než se naděješ\n"
            + "postaví před tebe 3 čaje - Puerh, Oolong a Senchu, aniž sis je objednal.\n"
            + "Dále povídá, že pan Godot už je na cestě, a ať se mezitím seznámím\n"
            + "s jiným zajímavým klientem, a ukáže na jednoho z živé skupinky kousek od vás.\n"
            + "- nové věci v místnosti - Hráč, Sencha, Oolong, Puerh\n"),
    AABARMAN2(
            "Divnej chlap, ten co jste s nim hrál, co?\n"
            + "Jak ho znám, strčil vám nějakou věc, o které vám neřek co dělá, co?\n"
            + "Jestli vás to zajímá, tak kus cesty odsud tramvají je stará pošta,\n"
            + "tam se usadil jeden takovej podivín, co se v těhle věcech vyzná,\n"
            + "prej poradil i Godotovi, aby s váma udělal ten obchod.\n"
            + "Jo a když jsme u něj, na něj bych se bejt váma zeptal ve VIP místnosti,\n"
            + "jestli jste tam už nebyl.\n"),
    AAHRAC(
            "Přisedneš k oné skupince. Než otevřeš ústa k pozdravu, začne host - \n"
            + "Dobrý den, vy tu čekáte na Godota, co? (probůh kolik lidí tu o mně vlastně ví!)\n"
            + "A tak ty že ano. No jo, to má tak někdo štěstí, mě můj dědeček neodkázal zhola nic,\n"
            + "vím zas tolik že to můžete prodávat. (kdy já jsem se zmiňoval o dědečkovi?)\n"
            + "Kdy jste se zmiňoval? (Co to má znamenat??!! Vždyť já nic neříkám! nebo jo?)\n"
            + "No neříkáte. Ale při troše cviku se dá docela dobře odhadnout co si člověk myslí.\n"
            + "Takže co to tu máme, pomyslíš si: Chlap co se neobtěžuje vyzvednout zboží,\n"
            + "ten smažka z nábřeží, co nakonec zmizel, a pak telepat. Super.\n"
            + "Následuje pro něj lehká, pro tebe vypjatá a nejistá konverzace o čtení myšlenek, psionice\n"
            + "o nově zvoleném papaláši včera ve zprávách, o myšlenkách obecně, o sugesci,\n"
            + "a nakonec tě telepat přesvědčí k jednoduchému pokusu.\n"
            + "Že prý si s ním máš zahrát kámen nůžky papír...\n"
            + "_________________________________________________________________________________________\n"
            + "A jak hrát? Zadáváš tři příkazy - kámen, nůžky nebo papír (pozor na malá/velká písmena)\n"
            + "Hraje se na tři vítězné. Můžeš zadat i příkaz konec, pro návrat do normální hry.\n"),
    AAOOLONG(
            "Usrkáváš neobyčejně lahodného čaje, myslíš si, že lepší jsi ještě nikdy neochutnal.\n"
            + "Země se pod tebou zachvěje, nakonec pukne, ozve se hrom a vidíš červený...\n"
            + "Néé, kecám, nic se nestalo."),
    AASENCHA(
            "Zelené čaje je někdy obtížné připravit správně.\n"
            + "U japonských je to nadlidský úkol. Ale komu čest, tomu čest,\n"
            + "zdejším kuchařům se to podařilo. Cítíš jemnost, ale ne zas tak fádní...\n"
            + "cítíš... cííítíííš... že se ti <zíííív> <chrrrrrr... chrrrrrr...>\n"
            + "Mohl bych být zlý a během spánku ti ukrást kufr,\n"
            + "ale jsem línej to programovat, takže tvůj majetek zůstane prozatím ušetřen.\n"),
    AAPUERH(
            "Silná svěží nasládlá chuť... no, to bych přeháněl, je to hnusné jak vyvařené fusekle,\n"
            + "ale nic člověka nenakopne víc. Nakoplo tě to tak, žes začal přemýšlet.\n"
            + "_____________________________________________________________________________________\n"
            + "NÁPOVĚDA\n"
            + "Telepata hned tak neporazíš! Musíš hrát něco jiného a myslet si něco jiného.\n"
            + "A jak to udělat? Napiš '(co chceš hrát) myslím (na co myslíš)',\n"
            + "třeba 'kámen myslím nůžky' nebo 'papír myslím papír'...\n"),
    AABASNIK(
            "Blížíš se k sedícímu mladíkovi. Čím blíž, tím jasněji vidíš, že jeho rysy...\n"
            + "jako by snad skoro žádné neměl. Jeho mumlání je hlasitější a hlasitější...\n"
            + "...mumlymumly... jako strašné oko... brblybrbly... slezu z té výše podivný kníže...\n"
            + "Polštář v koutě místnosti se na to chvatně vznesl do vzduchu, aby vzápětí spadl.\n"
            + "Přitom změnil barvu z červené na bílou. Plamen svíčky před mladíkem mezitím tančil\n"
            + "v bizarní směsici tvarů, vypadá to, že předměty v místnosti nějak vnímají chlapcova slova...\n"
            + "Ty, kdož vstoupils, pomoz mi s verši mými,\n"
            + "dnes nezbylo moc magie zde v síni,\n"
            + "když víc nás bude, už to půjde,\n"
            + "pak budeme silní\n"
            + "a já ti odpovím\n"
            + "na co se ptáš.\n"
            + "Málem ses otočil na podpatku, ale když vidíš, že klika na dveřích se výhrůžně naklonila\n"
            + "a dveře zavrčely jako pes, rozhodl ses posadit na pohodlné křeslo, v které se právě proměnila\n"
            + "lampa, která k tomu účelu ochotně seskočila ze stropu, až se jí třásla kola.\n"
            + "_____________________________________________________________________________________________\n"
            + "Básník ti bude klást verše, a tvým úkolem bude je prostě zrýmovat.\n"
            + "Ještě, protože jsem líný programátor, dodávám, že rým znamená pouze, že poslední tři písmena se shodují.\n"
            + "Ale abych tu srandu příliš nezdržoval, první verš je Co se děje, nemám zdání.\n"),
    AAPERLY1("Vytahuješ prak, nabíjíš jednu perlu a se zručností člověka z poslední generace,\n"
            + "jejíž dětství ještě sestávalo z lezení po stromech a honiček po dvorcích, ji vrháš proti parníku.\n"
            + "Za několik vteřin slyšíš slabé prasknutí. Perla dopadla. Před tebou se objeví tmavě modrý záblesk.\n"),
    AAPERLY2("A kdo se to z něj vynořil? Ztepilý chlapík v černém slavnostním šatu, trochu ponurém a strašidelném - \n"
            + "Konečně ses dočkal pana Godota! Ten není příliš překvapen, zjevně je na takové cestování trochu zvyklý.\n"
            + "NOVÁ VĚC V MÍSTNOSTI - Godot\n"),
    AAPERLY3("Ze záblesku ale nevystoupí pan Godot. Místo něj se objeví mladičký číšník s podnosem šampaňského.\n"
            + "Zapotácí se, zmateně se rozhlédne, roztržitě pozdraví dívaje se neznámo kam a nakonec odejde směrem\n"
            + "k nedaleké půjčovně lodiček, nejspíš aby nestrávil zbytečně dlouhou dobu mimo pracoviště. Cestou vypije dvě sklenky z podnosu.\n"
            + "Takže je vidět, že perly fungují, jen se umět soustředit, safra! Jen myslet na Godota a na nic jiného...\n"),
    AAPERLY4("Nesměle zašátráš ve váčku a vylovíš jednu z perel. Tu hodíš, ta letí malebným obloukem,\n"
            + "ale nakonec skončí v řece necelou čtvrtinu vzdálenosti mezi tebou a parníkem.\n"),
    AAPERLY5("Před tebou přistane hromada říčního bahna, která se zformuje do podoby ztepilého chlapíka ve svátečním,\n"
            + "nejspíš takhle nějak by vypadala socha pana Godota, ale za chvíli bahno spadne a zbude jen umazaná dlažba.\n"),
    AAPERLY6("Ozve se slabá rána a ve tvé náruči se objeví vypasený kapr. Ten sebou několikrát silně škubne,\n"
            + "až leží na dlažbě, po pár dalších škubnutích se mu podaří dostat zpátky do řeky, načež odplave neznámo kam\n"
            + "a zanechá tě mokrého, prosáklého pachem rybiny.\n"
            + "Vidíš, že perly fungují, jen ještě nemyslet na pitomosti a radši všechny své myšlenky soustředit právě na Godota...\n"),
    AAVETES1("Vejdeš dovnitř, na dveřích se ozve zvonek. Pan Harribat přestane listovat v tlusté knize, podívá se líně tvým směrem\n"
            + "a praví: Vítejte! Moc často tu hosty nevídám, zvláště ty normální! Tak  co pro vás mohu udělat?\n"),
    AAVETES2("Na to vytáhneš sáček perel a zeptáš se starce: Potřeboval bych vědět co je tohle.\n"
            + "Ten jednu perlu vytáhne zamumlá si něco pod vousy (jo, řekl jsem vám že má bílý plnovous?)\n"
            + "v perle něco zazáří tmavě modrým světlem. 'Tak tohle je tuze zajímavá věc, tu vám jistě dal ten telepat.\n"
            + "Tohle je totiž vážený pane Perla z konce světa, vlastně mnoho a mnoho perel z konce světa.\n"
            + "Ten kdo použije takovou PéKáEsku, ten může velmi snadno najít to, co zrovna shání.\n"
            + "Prostě si představí co chce najít, hodí perlu tam, kde předpokládá že to bude a pokud tam ta věc je, okamžitě se mu objeví nadosah ruky.'\n"),
    AAVETES3("Dále si tě kmet chvíli prohlíží. Takový kufřík, co s sebou nosíš, se hned tak neskryje. Proto se zájmem obchodníka pokračuje dál:\n"
            + "Tenhle kufřík, co máte u sebe, už jsem viděl. Vlastně jsem vašeho děda znal, chtěl jsem od něj ten kufřík odkoupit,\n"
            + "ale on si s ním vesele čaroval dál, a když pak přišel novější Kufřík 2S, koupil jsem si radši ten, čaruje se s ním o něco rychleji než s tímhle.'\n"
            + "Chvíli přechází po místnosti. Přitom povídá dál. 'Když ten Godot je na tom svém mecheche, hned tak se za ním nedostanete, nikdo se na loď nedostane bez pozvánky.\n"),
    AAVETES4("S těma vašema PKSkama by to možná šlo, pokud si vzpomenete co vám vykládal ten blázen co vám je dal. No a jestli umíte dobře házet.\n"
            + "Já vám s tím naštěstí můžu pomoct. Že jste to vy, něco vám dám... kam jsem to... Dovolíte?' Vzal ti perly z ruky, jednu vyndal a hodil někam do kouta\n"
            + "zakrámované místnosti. Ozvalo se tiché prasknutí a v mužově ruce se objevil kovový prak. 'Tohle by bylo na ten hod, s tím tu loď i trefíte.'\n"
            + "Pak ze stolku vzal jinou věc - kouli z broušeného skla, vypadá jako těžítko. 'A tohle je na to soustředění. Zesilovač myšlenek.\n"
            + "Ale teď už byste měl jít, nebo vám ta loď odjede, prej mají navečer odjet z města někam do přírody.'\n"
            + "Podá ti ruku a bez rozloučení se dál přehrabuje ve svých věcech.\n"
            + "NOVÉ VĚCI V MÍSTNOSTI - Prak a Těžítko\n"),
    VERSE("Teď už tě mladík nepotřebuje, aby rozjel opět své veršování.\n"
            + "Začal ostrým tempem:\n"
            + "Zdání klame,\n"
            + "náramně\n"
            + "Požij námel\n"
            + "židli naber\n"
            + "na rohy makových šroubů...\n"
            + "Svíčka se zatím schovala pod jeden z polštářů, plamen si jí nevšímal a na svém místě tančil dál.\n"
            + "Ze stropu vyrostla záchodová mísa, a protože gravitace tu stále byla skoro vpořádku,\n"
            + "proud z ní vydatně polil básníka. Ten si toho ani nevšiml a pokračoval dál,\n"
            + "i když se jedna ze stěn pokoje zdvořile uklonila, smekla buřinku a na kole odplula neznámo kam.\n"
            + "Řekl sis, že je na čase opustit místnost. Jen jsi prošel zpátky do čajovny, zmizely i dveře za tebou,\n"
            + "jakoby nikdy žádná VIP místnost neexistovala.\n"
            + "Tohle se tu děje často, zvolal na tebe barman. Jednou nám tu z toho udělal dětskej koutek z mekáče...\n"
            + "Tobě se však v tom zmatku do hlavy vloudila neodbytná, snad podsunutá zbloudilá myšlenka:\n"
            + "'Godot má dneska menší oslavu s přáteli. Pronajal si k tomu na řece parník. Já ho přesunul přímo před nábřeží.\n"
            + "Když jsem tohle kouzlo v září 2002 zkoušel, podařilo se mi vylejt všechny naše řeky z koryt, ale\n"
            + "tentokrát se mi to povedlo.'\n"),
    KNPLOSE("Ale to si nesmíte tak brát, konejší tě tvůj protihráč.\n"
            + "Víte, když čtete soupeři myšlenky, víte dopředu co bude hrát.\n"
            + "Tedy pokud se sám nesoustředí a sám vám neposílá matoucí myšlenky.\n"
            + "Dejte si nějaký čaj na baru a zkusíme to znovu.\n"),
    KNPWIN("Tak vidíte, sugesce funguje. A víte co, abyste na mně\n"
            + "nezapomněl, a abyste nezapomněl co jsem vám řek, vemte si tohle.\n"
            + "A položí před tebe jednoduchý váček z pytloviny.\n"
            + "V tomhle pytlíku, povídá, ten je plný něčeho, čemu já říkám perly.\n"
            + "Jsou mnohem větší a maj takovou modročernou barvu, vypadaj jako\n"
            + "skleněné kuličky, ale já něco podobného viděl někde, že tomu říkali perly.\n"
            + "Co dělaj vám neřeknu, ale abyste na to přišel,\n"
            + "vzpomeňte si na to co jsem vám říkal.\n"
            + "- nová věc v místnosti - Perly");
    //== Konstruktory a tovární metody =============================================
    private String text;

    //    /*************************************************************************
    //     *
    //     */
    Texty(String text) {
        this.text = text;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    public String getText() {
        return text;
    }
    //== Soukromé metody (instancí i třídy) ========================================
}
