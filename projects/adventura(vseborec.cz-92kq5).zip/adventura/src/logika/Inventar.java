package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
import java.util.Collection;
import java.util.Set;
import java.util.HashSet;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * *****************************************************************************
 * Instance třídy inventar představují ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
public class Inventar {

    //== Datové atributy (statické i instancí)======================================
    public Set<Vec> veci;
    private int kapacita;
    private int neseno = 0;
    private HerniPlan plan;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     *
     * @param plan - herní plán
     * @param kapacita - kolik předmětů inventář pojme
     */
    public Inventar(HerniPlan plan, int kapacita) {
        this.plan = plan;
        this.kapacita = kapacita;
        veci = new HashSet<>();
    }

    public int getVolnychMist() {
        return kapacita - neseno;
    }

    public int getKapacita() {
        return kapacita;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    public boolean vloz(Vec vec) {
        if ((neseno >= kapacita) || (!vec.jePrenositelna())) {
            return false;
        } else {
            veci.add(vec);
            neseno++;
            return true;
        }
    }

    public boolean zahod(Vec vec) {
        if ((veci.contains(vec))) {
            plan.getAktualniProstor().vlozVec(vec);
            veci.remove(vec);
            neseno--;
            return true;
        } else {
            return false;
        }
    }

    public Collection<Vec> getVeci() {
        return veci;
    }
    //== Soukromé metody (instancí i třídy) ========================================
}
