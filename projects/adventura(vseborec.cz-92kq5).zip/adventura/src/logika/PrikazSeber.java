package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy PrikazSeber představují ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
class PrikazSeber implements IPrikaz {

    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "seber";
    HerniPlan plan;
    Inventar inventar;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    public PrikazSeber(HerniPlan plan, Inventar inventar) {
        this.plan = plan;
        this.inventar = inventar;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    @Override
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            // pokud chybí druhé slovo (věc), tak ....
            return "Cožeto mám sebrat?";
        }

        if (parametry[0].equals("?")) {
            return "Nápověda pro příkaz seber: \n"
                    + "Pomocí příkazu sbíráte věci. Použití: seber (věc)";
        }

        Vec vec = jeTu(parametry[0]);

        if (plan.getAktualniProstor().getVeci().contains(vec)) {

            if (!(inventar.vloz(vec))) {
                return "Věc nelze sebrat.";
            }
            plan.getAktualniProstor().seberVec(vec);
            return "Sebral jsi " + (vec.getNazev()) + ". Můžeš sebrat ještě " + inventar.getVolnychMist() + " věcí.";
        } else {
            return "Volaná věc neexistuje.";
        }
    }

    private Vec jeTu(String vec) {
        Vec vystup = null;
        if (vystup == null) {
            for (Vec i : plan.getAktualniProstor().getVeci()) {
                if (i.getNazev().equalsIgnoreCase(vec)) {
                    vystup = i;
                }
            }
        }
        return vystup;
    }

    @Override
    public String getNazev() {
        return NAZEV;
    }
}
