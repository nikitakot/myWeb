package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy PrikazSeber představují ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
class PrikazZahod implements IPrikaz {

    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "zahod";
    HerniPlan plan;
    Inventar inventar;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    public PrikazZahod(HerniPlan plan, Inventar inventar) {
        this.plan = plan;
        this.inventar = inventar;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    @Override
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            // pokud chybí druhé slovo (věc), tak ....
            return "Cožeto mám zahodit?";
        }

        if (parametry[0].equals("?")) {
            return "Nápověda pro příkaz zahod: \n"
                    + "Příkazem můžete nějakou věc zahodit. Věc zůstane v místnosti, kde se nacházíte. \n"
                    + "Použití: zahod (věc)";
        }

        Vec vec = jeTu(parametry[0]);

        if (vec == null) {
            return "Tuhle věc nemáš, jak ji chceš zahodit?";
        }

        inventar.zahod(vec);
        return "zahodil jsi " + vec + ". Máš " + inventar.getVolnychMist()
                + " volných míst v inventáři.";
    }

    private Vec jeTu(String vec) {
        Vec vystup = null;
        for (Vec i : inventar.veci) {
            if (i.getNazev().equalsIgnoreCase(vec)) {
                vystup = i;
            }
        }
        return vystup;
    }

    @Override
    public String getNazev() {
        return NAZEV;
    }
}
