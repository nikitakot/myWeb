package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy Verse představují ...
 *
 * Druhá minihra, vítězství v ní způsobí změnu v prostorech
 *
 * @author Filip Gregor
 * @version 0.00.000
 */
public class Verse {

    private HerniPlan plan;
    private String[] vers = new String[5];
    private int krok = 0;
    private String tvujVers, mujVers;

    //== Datové atributy (statické i instancí)======================================
    //== Konstruktory a tovární metody =============================================
    /**
     * *************************************************************************
     * Konstruktor ....
     *
     * @param plan - herní plán
     */
    public Verse(HerniPlan plan) {
        this.plan = plan;
        vers[0] = "Co se děje, nemám zdání";
        vers[1] = "Ale když se to už děje";
        vers[2] = "Tak tu z plna hrdla křičím";
        vers[3] = "Pak že se mi nelení";
        vers[4] = "Co se děje, nemám zdání";
    }

    public String proved(String... parametry) {
        if (parametry[0].equals("konec")) {
            plan.setMinihra(null);
            return "Hra ukončena, vzdal ses." + "\n" + plan.getAktualniProstor().dlouhyPopis();
        }

        mujVers = "nic";

        if (parametry[0].equals("") && (parametry.length <= 1)) {
            return vers[krok];
        } else {

            tvujVers = parametry[parametry.length - 1];
            mujVers = vers[krok];

            if (tvujVers.length() >= 3) {
                tvujVers = tvujVers.substring(tvujVers.length() - 3);
            } else {
                return "nějak se ti to nerýmuje";
            }
            if (mujVers.length() >= 3) {
                mujVers = mujVers.substring(mujVers.length() - 3);
            } else {
                return "nějak se ti to nerýmuje";
            }

        }
        if (tvujVers.equals(mujVers.substring(mujVers.length() - 3))) {
            krok++;
            if (krok >= vers.length) {
                krok = 0;
                plan.setMinihra(null);
                plan.setAktualniProstor(plan.getAktualniProstor().vratSousedniProstor("Čajovna"));

                plan.getAktualniProstor().odeberVychod("VIPmístnost");
                Prostor nabrezi = plan.getAktualniProstor().vratSousedniProstor("Nábřeží");
                nabrezi.vlozVec(Vec.parnik);
                plan.getAktualniProstor().setSouborMapy("/zdroje/mapCajovna2.gif");
                nabrezi.setSouborMapy("/zdroje/mapNabrezi2.gif");
                plan.upozorniPozorovatele();
                return Texty.VERSE.getText() + "\n" + plan.getAktualniProstor().dlouhyPopis();
            }
            return vers[krok];
        } else {
            return "nějak se ti to nerýmuje\n" + vers[krok];
        }
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    //== Soukromé metody (instancí i třídy) ========================================
}
