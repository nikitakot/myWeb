package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy PrikazPouzij představují ...
 *
 * @author Filip Gregor
 * @version 0.00.000
 */
class PrikazPouzij implements IPrikaz {

    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "pouzij";
    HerniPlan plan;
    Inventar inventar;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    public PrikazPouzij(HerniPlan plan, Inventar inventar) {
        this.plan = plan;
        this.inventar = inventar;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    @Override
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            // pokud chybí druhé slovo (věc), tak ....
            return "Cožeto mám použít?";
        }

        if (parametry[0].equals("?")) {
            return "Nápověda pro příkaz pouzij: \n"
                    + "Zřejmě nejdůležitější příkaz ve hře, pomocí tohoto příkazu používáte věci\n"
                    + "nebo komunikujete s postavami.\n"
                    + "Použití: \n Pro použití samostatného předmětu: pouzij (věc)"
                    + "Pro komblinaci předmětů nebu jejich vzájemnou interakci (a mimo jiné předávání věcí postavám)\n"
                    + "pouzij (co) (na co(koho)) např. pouzij Klíč Dveře";
        }

        Vec prvniVec = jeTu(parametry[0]);
        Vec druhaVec = null;
        if (prvniVec == null) {
            return parametry[0] + " tu není.";
        }
        if (parametry.length >= 2) {
            druhaVec = jeTu(parametry[1]);
            if (druhaVec == null) {
                return parametry[1] + " tu není.";
            }
        }

        if (prvniVec.pouzijNaCo() == druhaVec) {

            if (prvniVec.naJednoPouziti()) {
                inventar.zahod(prvniVec);
                plan.getAktualniProstor().seberVec(prvniVec);
                plan.upozorniPozorovatele();
            }

            if (druhaVec == null) {
                return "Používám " + parametry[0] + ".\n" + plan.akce(prvniVec);
            } else {
                return "Používám " + parametry[0] + " na " + parametry[1] + ".\n" + plan.akce(prvniVec);
            }
        } else {
            return "Toto nelze vykonat/Takto nelze věci zkombinovat.";
        }
    }

    private Vec jeTu(String vec) {
        Vec vystup = null;
        for (Vec i : inventar.veci) {
            if (i.getNazev().equalsIgnoreCase(vec)) {
                vystup = i;
            }
        }
        if (vystup == null) {
            for (Vec i : plan.getAktualniProstor().getVeci()) {
                if (i.getNazev().equalsIgnoreCase(vec)) {
                    vystup = i;
                }
            }
        }
        return vystup;
    }

    @Override
    public String getNazev() {
        return NAZEV;
    }

    //== Soukromé metody (instancí i třídy) ========================================
}
