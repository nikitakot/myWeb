package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy PrikazKdejsem představují ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
class PrikazKdejsem implements IPrikaz {

    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "kdejsem";
    private HerniPlan plan;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    public PrikazKdejsem(HerniPlan plan) {
        this.plan = plan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    //== Nesoukromé metody (instancí i třídy) ======================================
    @Override
    public String proved(String... parametry) {
        if (parametry.length > 0 && parametry[0].equals("?")) {
            return "Nápověda pro příkaz kdejsem: \n"
                    + "Vypisuje, ve které místnosti se nacházíte, její východy a předměty.\n"
                    + "Použití: kdejsem";
        }

        return plan.getAktualniProstor().dlouhyPopis();

    }

    @Override
    public String getNazev() {
        return NAZEV;
    }

    //== Soukromé metody (instancí i třídy) ========================================
}
