package logika;

import java.util.*;
import util.Observer;
import util.SubjektObserveru;

/**
 * Class HerniPlan - třída představující mapu a stav adventury.
 *
 * Tato třída inicializuje prvky ze kterých se hra skládá: vytváří všechny
 * prostory, propojuje je vzájemně pomocí východů a pamatuje si aktuální
 * prostor, ve kterém se hráč právě nachází. Také zajišťuje interakci předmětů s
 * okolím.
 *
 * @author Michael Kolling, Lubos Pavlicek, Jarmila Pavlickova, Filip Gregor
 * @version pro školní rok 2013/2014
 */
public class HerniPlan implements SubjektObserveru {

    private List<Observer> seznamPozorovatelu;

    private Inventar inventar;
    private String minihra = null;
    private boolean Vyhra = false;
    private boolean Prohra = false;
    private String zpravaNaKonec;
    private boolean tutorial = true;

    private Prostor aktualniProstor;
    private Prostor byt, pokoj, loznice, nabrezi, cajovna, vip, posta;

    //proměnné potřebné v průběhu
    boolean pouzilJsemBarmana = false;

    /**
     * Konstruktor který vytváří jednotlivé prostory a propojuje je pomocí
     * východů. Jako výchozí aktuální prostor nastaví halu.
     */
    public HerniPlan() {
        zalozProstoryHry();
        seznamPozorovatelu = new ArrayList<Observer>();
    }

    /**
     * Vytváří jednotlivé prostory a propojuje je pomocí východů. Jako výchozí
     * aktuální prostor nastaví předsíň. Také vytváří věci a přidává je do
     * místností.
     */
    private void zalozProstoryHry() {
        // vytvářejí se jednotlivé prostory

        //MŮJ BYT
        byt = new Prostor("Předsíň", "Jsi v předsíni svého bytu.");
        pokoj = new Prostor("Pokoj", "Vešel jsi do pokoje.", Texty.POKOJ.getText());
        loznice = new Prostor("Ložnice", "Jsi v ložnici.", "Ložnici vévodí skromná postel, noční stolek a stará lampa. Klíč tu ale není.");

        // (název věci, přenositelnost, na ceho lze použít, jestli lze použít jen jednou, podrobnější popis)
        // (název věci, přenositelnost, podrobnější popis)
        byt.vlozVec(Vec.dvere);
        pokoj.vlozVec(Vec.klic);
        pokoj.vlozVec(Vec.kufrik);
        byt.vlozVec(Vec.vypinac);
        loznice.vlozVec(Vec.stolek);
        loznice.vlozVec(Vec.postel);

        //ČAJOVNA
        cajovna = new Prostor("Čajovna", Texty.CAJOVNA.getText());
        vip = new Prostor("VIPmístnost", Texty.VIP.getText());

        cajovna.vlozVec(Vec.barman);
        vip.vlozVec(Vec.basnik);

        //NÁBŘEŽÍ
        nabrezi = new Prostor("Nábřeží", "Došel jsi na rozlehlé nábřeží.", Texty.NABREZI.getText());

        posta = new Prostor("Pošta", Texty.POSTA.getText());

        //nastaveni map prostoru pro grafiku
        byt.setSouborMapy("/zdroje/mapByt.gif");
        pokoj.setSouborMapy("/zdroje/mapByt.gif");
        loznice.setSouborMapy("/zdroje/mapByt.gif");
        cajovna.setSouborMapy("/zdroje/mapCajovna.gif");
        vip.setSouborMapy("/zdroje/mapCajovna.gif");
        nabrezi.setSouborMapy("/zdroje/mapNabrezi.gif");
        posta.setSouborMapy("/zdroje/mapPosta.gif");

        byt.setPoziceZnackyInt(10, 10);
        pokoj.setPoziceZnackyInt(20, 10);
        loznice.setPoziceZnackyInt(30, 10);
        cajovna.setPoziceZnackyInt(40, 10);
        vip.setPoziceZnackyInt(50, 10);
        nabrezi.setPoziceZnackyInt(60, 10);
        posta.setPoziceZnackyInt(70, 10);

        nabrezi.vlozVec(Vec.pan);
        nabrezi.vlozVec(Vec.zastavkaN);

        //POŠTA
        posta.vlozVec(Vec.zastavkaP);
        posta.vlozVec(Vec.vetesnik);

        // průchody v mém bytě
        byt.setVychod(pokoj);
        loznice.setVychod(pokoj);
        pokoj.setVychod(loznice);
        byt.setVychod(loznice);
        loznice.setVychod(byt);
        pokoj.setVychod(byt);

        // průchody v čajovně
        cajovna.setVychod(vip);
        vip.setVychod(cajovna);
        cajovna.setVychod(nabrezi);
        nabrezi.setVychod(cajovna);

        aktualniProstor = byt;  // hra začíná v mém bytě
    }

    /**
     * Nastaví inventář, s kterým bude herní plán komunikovat. Je nutné nastavit
     * samostatně, protože herní plán je vytvořen dřív než inventář, nicméně
     * inventář herní plán také používá.
     *
     * @param inventar - inventář
     */
    public void setInventar(Inventar inventar) {
        this.inventar = inventar;
    }

    /**
     * Metoda vrací odkaz na aktuální prostor, ve ktetém se hráč právě nachází.
     *
     * @return aktuální prostor
     */
    public Prostor getAktualniProstor() {
        return aktualniProstor;
    }

    /**
     * Metoda nastaví aktuální prostor, používá se nejčastěji při přechodu mezi
     * prostory
     *
     * @param prostor nový aktuální prostor
     */
    public void setAktualniProstor(Prostor prostor) {
        aktualniProstor = prostor;
    }

    /**
     * Nejdůležitější metoda - pokud čtete tento komentář, neměl jsem čas z ní
     * opět udělat samostatnou třídu, jak jsem již chtěl, ale z technických
     * důvodů neudělal. Tato metoda zajišťuje všechny interakce předmětů s
     * okolím i se sebou. Přes tuto metodu jsem nastavil vítězství i prohru, je
     * to metoda, která vypráví příběh...
     *
     * @param ceho - string: akce čeho se má provést?
     * @return text, který vypíše příkaz Pouzij
     */
    public String akce(Vec ceho) {
        if (ceho.equals(Vec.klic)) {
            byt.setVychod(nabrezi);
            nabrezi.setVychod(byt);
            if (tutorial) {
                tutorial = false;
                return Texty.AAKLIC.getText();
            }
            return "Odemykám dveře, nyní je možní jít na Nábřeží.";
        }
        if (ceho.equals(Vec.postel)) {
            return Texty.AAPOSTEL.getText();
        }
        if (ceho.equals(Vec.stolek)) {
            loznice.vlozVec(Vec.pistole);
            return Texty.AASTOLEK.getText();
        }
        if (ceho.equals(Vec.pistole)) {
            Prohra = true;
            zpravaNaKonec = Texty.AAPISTOLE.getText();
            return "";
        }
        if (ceho.equals(Vec.dvere)) {
            if (byt.getVychody().contains(nabrezi)) {
                return "Dveře jsou odemčené, dostaneš se jimi na nábřeží.";
            } else {
                if (tutorial) {
                    return Texty.AADVERE.getText();
                }
                return "Dveře jsou zamčené, musíš najít klíč.";
            }
        }
        if (ceho.equals(Vec.vypinac)) {
            if (tutorial) {
                tutorial = false;
                return "Vypnul jste tutoriál.";
            } else {
                return "Mdlá žárovka se rozsvěcí a zhasíná, jak cvakáte vypínačem.";
            }
        }

        if (ceho.equals(Vec.pan)) {
            aktualniProstor.seberVec(Vec.pan);
            return Texty.AAPAN.getText();
        }
        if (ceho.equals(Vec.kupec)) {
            return "Zde je tvůj kupec, úkolem hry je přinést mu kufřík.";
        }
        if (ceho.equals(Vec.kufrik)) {
            Vyhra = true;
            zpravaNaKonec = Texty.AAKUFR.getText();
            return "";
        }
        if (ceho.equals(Vec.zastavkaN)) {
            if (aktualniProstor.equals(nabrezi)) {
                setAktualniProstor(posta);
                return Texty.AAZASTN.getText()
                        + aktualniProstor.dlouhyPopis();
            }
        }
        if (ceho.equals(Vec.zastavkaP)) {
            setAktualniProstor(nabrezi);
            return Texty.AAZASTP.getText()
                    + aktualniProstor.dlouhyPopis();
        }
        if (ceho.equals(Vec.barman)) {
            if (pouzilJsemBarmana) {
                return Texty.AABARMAN2.getText();
            } else {
                nabrezi.seberVec(Vec.pan);
                cajovna.vlozVec(Vec.hrac);
                cajovna.vlozVec(Vec.sencha);
                cajovna.vlozVec(Vec.oolong);
                cajovna.vlozVec(Vec.puerh);
                pouzilJsemBarmana = true;
                return Texty.AABARMAN1.getText();
            }
        }
        if (ceho.equals(Vec.hrac)) {
            minihra = "KNP";
            return Texty.AAHRAC.getText();
        }
        if (ceho.equals(Vec.oolong)) {
            return Texty.AAOOLONG.getText();
        }
        if (ceho.equals(Vec.sencha)) {
            return Texty.AASENCHA.getText();
        }
        if (ceho.equals(Vec.puerh)) {
            return Texty.AAPUERH.getText();
        }
        if (ceho.equals(Vec.basnik)) {
            minihra = "Vers";
            return Texty.AABASNIK.getText();
        }
        if (ceho.equals(Vec.perly)) {
            String vystup = "Převažuješ pytlík perel v ruce. ";
            Collection<Vec> vecInv = inventar.getVeci();
            boolean mamP = false;
            boolean mamZ = false;
            for (Vec i : vecInv) {
                if (i.getNazev().equals("Prak")) {
                    mamP = true;
                }
                if (i.getNazev().equals("Těžítko")) {
                    mamZ = true;
                }
            }
            if (mamP) {
                vystup += Texty.AAPERLY1.getText();
                if (mamZ) {
                    nabrezi.vlozVec(Vec.kupec);
                    vystup += Texty.AAPERLY2.getText();
                } else {
                    vystup += Texty.AAPERLY3.getText();
                }
            } else {
                vystup += Texty.AAPERLY4.getText();
                if (mamZ) {
                    vystup += Texty.AAPERLY5.getText();
                } else {
                    vystup += Texty.AAPERLY6.getText();
                }
            }
            return vystup;
        }
        if (ceho.equals(Vec.vetesnik)) {
            String vystup = Texty.AAVETES1.getText();
            Collection<Vec> vecInv = inventar.getVeci();
            boolean mamP = false;
            boolean mamK = false;
            for (Vec i : vecInv) {
                if (i.getNazev().equals("Perly") && (!inventar.getVeci().contains(Vec.prak))) {
                    mamP = true;
                    vystup += Texty.AAVETES2.getText();
                }
                if (i.getNazev().equals("Kufřík") && (!inventar.getVeci().contains(Vec.zesilovac))) {
                    mamK = true;
                    vystup += Texty.AAVETES3.getText();
                }
            }
            if (mamP && mamK) {
                aktualniProstor.vlozVec(Vec.prak);
                aktualniProstor.vlozVec(Vec.zesilovac);
                vystup += Texty.AAVETES4.getText();
            }
            return vystup;
        }
        return "Akce: tenhle předmět neznám: " + ceho;
    }

    /**
     * je zapnutý tutoriál?
     *
     * @return je nebo není?
     */
    public boolean vyuka() {
        return tutorial;
    }

    public Inventar getInventar() {
        return inventar;
    }

    public boolean getVyhra() {
        return Vyhra;
    }

    public boolean getProhra() {
        return Prohra;
    }

    public String getMinihra() {
        return minihra;
    }

    /**
     * Pokud minihra není null, Hra nezpracehovává příkazy, ale místo nich hraje
     * právě jednu ze (zatím dvou) miniher.
     *
     * @param set - jméno minihry
     */
    public void setMinihra(String set) {
        this.minihra = set;
    }

    public String getZpravaNaKonec() {
        return zpravaNaKonec;
    }

    public void zaregistrujPozorovatele(Observer pozorovatel) {
        seznamPozorovatelu.add(pozorovatel);
    }

    public void odregistrujPozorovatele(Observer pozorovatel) {
        seznamPozorovatelu.remove(pozorovatel);
    }

    public void upozorniPozorovatele() {
        for (Observer pozorovatel : seznamPozorovatelu) {
            pozorovatel.aktualizuj(aktualniProstor);
        }
    }
}
