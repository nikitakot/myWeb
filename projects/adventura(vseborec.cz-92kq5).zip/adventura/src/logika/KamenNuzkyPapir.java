package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy KamenNuzkyPapir představují ...
 *
 * První ze dvou miniher, po jejím úspěšném zvládnutí hráč získá klíčkvý předmět
 *
 * @author Filip Gregor
 * @version 0.00.000
 */
public class KamenNuzkyPapir {

    //== Datové atributy (statické i instancí)======================================
    //== Konstruktory a tovární metody =============================================
    private static final String KAMEN = "kámen";
    private static final String NUZKY = "nůžky";
    private static final String PAPIR = "papír";
    private HerniPlan plan;
    private String myslim, souper;
    private int skoreJa, skoreSouper;

    /**
     * *************************************************************************
     * Konstruktor ....
     *
     * @param plan - herní plán
     */
    public KamenNuzkyPapir(HerniPlan plan) {
        this.plan = plan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    public String proved(String... parametry) {
        String out = "";
        String hraju = "";

        if (parametry.length == 0) {
            return "Musíš něco zadat.";
        }
        if (parametry[0].equals("konec")) {
            plan.setMinihra(null);
            return "Hra skončila, vzdal ses." + "\n" + plan.getAktualniProstor().dlouhyPopis();
        }
        if ((parametry[0].equals(KAMEN)) || (parametry[0].equals(NUZKY)) || (parametry[0].equals(PAPIR))) {
            out = "Hraju " + parametry[0];
        } else {
            return "Musíš zadat kámen, nůžky, papír nebo konec.";
        }
        if ((parametry.length > 1) && (parametry[1].equals("myslím"))) {
            out += " myslím ";

            if (!(parametry.length > 2)) {
                return "Co myslíš?";
            }
            if ((parametry[2].equals(KAMEN)) || (parametry[2].equals(NUZKY)) || (parametry[2].equals(PAPIR))) {
                out += parametry[2];
            } else {
                return "Myslíš na kraviny, zkus myslet na něco jiného";
            }
        }

        hraju = parametry[0];
        if (parametry.length > 1) {
            myslim = parametry[2];
        } else {
            myslim = parametry[0];
        }

        if (myslim.equals(KAMEN)) {
            souper = PAPIR;
        }
        if (myslim.equals(NUZKY)) {
            souper = KAMEN;
        }
        if (myslim.equals(PAPIR)) {
            souper = NUZKY;
        }

        if (hraju.equals(souper)) {
            out += "\n" + "Oba hrajete stejně";
        }

        if ((hraju.equals(KAMEN)) && (souper.equals(PAPIR))) {
            skoreSouper++;
            out += "\n" + "Bod soupeři, skóre je " + skoreJa + ":" + skoreSouper;
        }
        if ((hraju.equals(NUZKY)) && (souper.equals(KAMEN))) {
            skoreSouper++;
            out += "\n" + "Bod soupeři, skóre je " + skoreJa + ":" + skoreSouper;
        }
        if ((hraju.equals(PAPIR)) && (souper.equals(NUZKY))) {
            skoreSouper++;
            out += "\n" + "Bod soupeři, skóre je " + skoreJa + ":" + skoreSouper;
        }

        if ((hraju.equals(NUZKY)) && (souper.equals(PAPIR))) {
            skoreJa++;
            out += "\n" + "Bod tobě, skóre je " + skoreJa + ":" + skoreSouper;
        }
        if ((hraju.equals(PAPIR)) && (souper.equals(KAMEN))) {
            skoreJa++;
            out += "\n" + "Bod tobě, skóre je " + skoreJa + ":" + skoreSouper;
        }
        if ((hraju.equals(KAMEN)) && (souper.equals(NUZKY))) {
            skoreJa++;
            out += "\n" + "Bod tobě, skóre je " + skoreJa + ":" + skoreSouper;
        }

        if (skoreSouper >= 3) {
            out = "Soupeř tě porazil " + skoreJa + ":" + skoreSouper + "\n";
            out += Texty.KNPLOSE.getText() + "\n" + plan.getAktualniProstor().dlouhyPopis();

            skoreJa = 0;
            skoreSouper = 0;
            plan.setMinihra(null);
        }
        if (skoreJa >= 3) {
            out = "Vyhrál jsi " + skoreJa + ":" + skoreSouper + "\n";
            out += Texty.KNPWIN.getText();

            plan.getAktualniProstor().vlozVec(Vec.perly);
            plan.getAktualniProstor().seberVec(Vec.hrac);
            plan.upozorniPozorovatele();

            out += "\n" + plan.getAktualniProstor().dlouhyPopis();

            skoreJa = 0;
            skoreSouper = 0;
            plan.setMinihra(null);
        }
        return out;

    }
}
