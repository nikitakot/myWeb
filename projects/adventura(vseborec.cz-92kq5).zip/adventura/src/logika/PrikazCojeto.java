package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy PrikazCojeto představují ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
class PrikazCojeto implements IPrikaz {

    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "cojeto";
    HerniPlan plan;
    Inventar inventar;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    public PrikazCojeto(HerniPlan plan, Inventar inventar) {
        this.plan = plan;
        this.inventar = inventar;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    @Override
    public String proved(String... parametry) {
        if (parametry.length == 0) {
            // pokud chybí druhé slovo (věc), tak ....
            return "Co je co?";
        }

        if (parametry[0].equals("?")) {
            return "Nápověda pro příkaz cojeto: \n"
                    + "Nevíte, co která věc může dělat? Příkaz cojeto zobrazí její podrobnější popis\n"
                    + "Použití: cojeto (věc)";
        }

        String vec = parametry[0];
        Vec coJeCo = null;

        for (Vec i : inventar.veci) {
            if (i.getNazev().equalsIgnoreCase(vec)) {
                coJeCo = i;
            }
        }
        if (coJeCo == null) {
            for (Vec i : plan.getAktualniProstor().getVeci()) {
                if (i.getNazev().equalsIgnoreCase(vec)) {
                    coJeCo = i;
                }
            }
        }
        if (coJeCo == null) {
            return vec + "? Buď to nemáš a není to v místnosti, nebo nevím co to je...";
        }

        return coJeCo.getCojeto();

    }

    @Override
    public String getNazev() {
        return NAZEV;
    }
    //== Soukromé metody (instancí i třídy) ========================================

}
