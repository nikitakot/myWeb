package logika;

import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy Vec představují ...
 *
 * @author Pavlíčková
 * @version 0.00.000
 */
public enum Vec {
    //== Datové atributy (statické i instancí)======================================

    dvere("Dveře", false, "Těžké dveře, přes které se nikdo nepovolaný nedostane", "/zdroje/dvere.gif"),
    klic("Klíč", true, dvere, true, "Klíč, který odemkne dveře ven", "/zdroje/klic.gif"),
    pistole("Pistole", true, null, true, Texty.PISTOLE.getText(), "/zdroje/pistole.gif"),
    vypinac("Vypínač", false, "Ručně ovládaný mechanický spínač k zapínání a vypínání osvětlení (Zdroj:Wikipedie)", "/zdroje/vypinac.gif"),
    stolek("Stolek", false, null, true, "Malý stolek se zásuvkou", "/zdroje/stolek.gif"),
    postel("Postel", false, "Postel? Spíš jen lehátko. Ale na spaní stačí.", "/zdroje/postel.gif"),
    barman("Barman", false, "Holohlavý chlapík s bradkou, od krku s nějakým tetováním", "/zdroje/barman.gif"),
    hrac("Hráč", false, "Jeden ze členů početné skupiny semknuté kolem hudebníka", "/zdroje/hrac.gif"),
    sencha("Sencha", false, null, true, "Lehký, uklidňující zelený čaj", "/zdroje/sencha.gif"),
    oolong("Oolong", false, null, true, "Lahodný polozelený čaj s obsahem kofeinu", "/zdroje/oolong.gif"),
    puerh("Puerh", false, null, true, "Čínský silný černý čaj, pro soustředění a 'nakopnutí'", "/zdroje/puerh.gif"),
    basnik("Básník", false, null, true, "Neustále si mumlající mladík", "/zdroje/basnik.gif"),
    pan("Pán", false, "Mladík s dredy, který se dívá tvým směrem a se zájmem si tě prohlíží", "/zdroje/pan.gif"),
    kupec("Godot", false, "Vytáhlý chlapík s vizáží jak vystřiženou z filmů Tima Burtona", "/zdroje/godot.gif"),
    zastavkaN("Zastávka", false, "Tramvajová zastávka hned vedle nábřeží", "/zdroje/zastavka.gif"),
    zastavkaP("Zastávka", false, "Tramvajová zastávka vyhlížející o mnoho méně zchátrale než budova pošty", "/zdroje/zastavka.gif"),
    vetesnik("Vetešník", false, "Starý muž ve starém obleku zahrabaný starými krámy", "/zdroje/vetesnik.gif"),
    prak("Prak", true, Texty.PRAK.getText(), "/zdroje/prak.gif"),
    zesilovac("Těžítko", true, Texty.TEZITKO.getText(), "/zdroje/tezitko.gif"),
    parnik("Parník", false, "Starý parník s mohutným kolesem vzadu, pluje celkem daleko od břehu...", "/zdroje/parnik.gif"),
    perly("Perly", true, parnik, false, "Sáček z režné pytloviny plný černo-modrých, jakoby skleněných kuliček", "/zdroje/perla.gif"),
    kufrik("Kufřík", true, kupec, true, "Otlučený kufr potažený černou koženkou", "/zdroje/kufr.gif");

    private String nazev;
    private boolean prenositelnost;
    private Vec pouzijNa;
    private String cojeto;
    private boolean jenJednou = false;
    private String ikona;
    private ImageIcon ico;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    Vec(String nazev, boolean prenositelnost, Vec pouzijNa, String cojeto, String ikona) {
        this.nazev = nazev;
        this.prenositelnost = prenositelnost;
        this.pouzijNa = pouzijNa;
        this.cojeto = cojeto;
        this.ico = priradIkonu(ikona);
    }

    Vec(String nazev, boolean prenositelnost, Vec pouzijNa, boolean jenJednou, String cojeto, String ikona) {
        this.nazev = nazev;
        this.prenositelnost = prenositelnost;
        this.pouzijNa = pouzijNa;
        this.jenJednou = jenJednou;
        this.cojeto = cojeto;
        this.ico = priradIkonu(ikona);
    }

    Vec(String nazev, boolean prenositelnost, String cojeto, String ikona) {
        this.nazev = nazev;
        this.prenositelnost = prenositelnost;
        this.cojeto = cojeto;
        this.ico = priradIkonu(ikona);
    }

    private ImageIcon priradIkonu(String ikona) {

        ImageIcon ico;
        URL umisteniObrazku = this.getClass().getResource(ikona);
        if (umisteniObrazku == null) {
            JOptionPane.showMessageDialog(null, "Soubor s obrázkem " + ikona + " nebyl nalezen", "Chyba při načítání obrázku", JOptionPane.ERROR_MESSAGE);
            return null;
        } else {
            ico = new ImageIcon(umisteniObrazku);
            return ico;
        }
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    public Vec pouzijNaCo() {
        return pouzijNa;
    }

    public String getNazev() {
        return nazev;
    }

    public String getCojeto() {
        return cojeto;
    }

    public boolean jePrenositelna() {
        return prenositelnost;
    }

    public boolean naJednoPouziti() {
        return jenJednou;
    }

    public ImageIcon getIcon() {
        return ico;
    }
    //== Soukromé metody (instancí i třídy) ========================================
}
