package logika;

/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
/**
 * *****************************************************************************
 * Instance třídy prikazInventar představují ...
 *
 * @author jméno autora
 * @version 0.00.000
 */
class PrikazInventar implements IPrikaz {

    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "inventar";
    private Inventar inventar;
    //== Konstruktory a tovární metody =============================================

    /**
     * *************************************************************************
     * Konstruktor ....
     */
    public PrikazInventar(Inventar inventar) {
        this.inventar = inventar;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    @Override
    public String proved(String... parametry) {
        if (parametry.length > 0 && parametry[0].equals("?")) {
            return "Nápověda pro příkaz inventar: \n"
                    + "Vypisuje obsah inventáře a počet volných míst. Použití: napište inventar";
        }

        String vystup = "";
        if (inventar.getVolnychMist() == inventar.getKapacita()) {
            vystup += "Inventář je prázdný, celkem lze nést " + inventar.getKapacita() + " předmětů.";
        } else {
            String seznam = "";
            for (Vec i : inventar.getVeci()) {
                seznam += (" " + i.getNazev());
            }

            vystup += "Věci v inventáři:" + seznam + "\n"
                    + " - Volných míst v inventáři: " + inventar.getVolnychMist();
        }
        return vystup;
    }

    @Override
    public String getNazev() {
        return NAZEV;
    }
    //== Soukromé metody (instancí i třídy) ========================================   
}
